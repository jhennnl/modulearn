package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentEnrolledBinding

class HumssModuleFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var dataList: ArrayList<dataClass2>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>
    private lateinit var quizList: Array<Int>
    private lateinit var contextList: Array<String>

    private var _binding: FragmentEnrolledBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEnrolledBinding.inflate(inflater, container, false)

        binding.moduleTitle.text = "HUMSS Modules"

        imageList = arrayOf(
            R.drawable.culture,
            R.drawable.philosopher,
            R.drawable.therapy
        )

        titleList = arrayOf(
            "Module 1: Arts and Culture",
            "Module 2: Philosophy and Society",
            "Module 3: Psychology and Media"
        )

        quizList = arrayOf(
            R.id.HUMSS_to_Quiz1,
            R.id.HUMSS_to_Quiz2,
            R.id.HUMSS_to_Quiz3
        )

        contextList = arrayOf(
            "5 Lessons",
            "3 Lessons",
            "3 Lessons"
        )


        recyclerView = binding.recyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.setHasFixedSize(true)

        dataList = arrayListOf()
        getData()

        binding.changeStrandText.setOnClickListener {
            findNavController().navigate(R.id.HUMSS_to_ChangeStrand)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData() {
        for (i in imageList.indices) {
            val data = dataClass2(imageList[i], titleList[i], quizList[i], contextList[i])
            dataList.add(data)
        }

        recyclerView.adapter = adapterClass2(dataList) { selectedItem, isQuizButton ->
            val navController = findNavController()
            if (isQuizButton) {
                navController.navigate(selectedItem.quizFragment)
            } else {
                when (selectedItem.dataTitle) {
                    "Module 1: Arts and Culture" -> navController.navigate(R.id.HUMSS_HumssM1)
                    "Module 2: Philosophy and Society" -> navController.navigate(R.id.HUMSS_HumssM2)
                    "Module 3: Psychology and Media" -> navController.navigate(R.id.HUMSS_HumssM3)
                }
            }
        }
    }
}
