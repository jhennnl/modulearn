package com.example.finalsappdev.ui.settings

import android.content.Context
import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        val sharedPreferences = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        // Retrieve user data
        val firstName = sharedPreferences.getString("firstName", "Unknown")
        val lastName = sharedPreferences.getString("lastName", "User")
        val username = sharedPreferences.getString("username", "No Username")

        binding.context2.text = "$firstName"
        binding.context4.text = "$lastName"
        binding.context6.text = "$username"

        binding.logoutBtn.setOnClickListener { logout() }

        binding.aboutDeveloperBtn.setOnClickListener {
            findNavController().navigate(R.id.aboutdevelopers)
        }

        return binding.root
    }

    private fun logout() {
        AlertDialog.Builder(requireContext())
            .setMessage("Are you sure you want to log out?")
            .setPositiveButton("Yes") { _, _ ->
                requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE).edit().clear().apply()
                findNavController().navigate(R.id.action_settingsFragment_to_getStartedFragment)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
