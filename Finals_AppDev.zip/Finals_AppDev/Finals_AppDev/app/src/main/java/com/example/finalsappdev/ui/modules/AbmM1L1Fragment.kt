package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM1L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Business Fundamentals"
        binding.lessontextView.text = "Lesson 1: Introduction to ABM"
        binding.readingContent.text = "ABM (Accountancy, Business, and Management) is a strand designed for students who want to enter the world of business, finance, and entrepreneurship."

        val lessons = listOf(
            "Accounting is the systematic process of recording, summarizing, and analyzing financial transactions. It helps businesses track income, expenses, and profitability.",
            "Marketing is the process of promoting and selling products or services. It involves strategies like advertising, branding, and customer engagement.",
            "Entrepreneurship is the ability to create and manage a business venture. Entrepreneurs identify opportunities, take risks, and develop innovative solutions.",
            "Financial management involves planning, organizing, and controlling financial resources. It ensures a company remains profitable and sustainable.",
            "Human resource management focuses on recruiting, training, and retaining employees. It helps businesses build strong and efficient teams."
        )

        val heading = listOf(
            "Accounting: The Language of Business",
            "Marketing: The Art of Selling",
            "Entrepreneurship: Turning Ideas into Business",
            "Financial Management: Handling Money Wisely",
            "Human Resource Management: Managing People"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
