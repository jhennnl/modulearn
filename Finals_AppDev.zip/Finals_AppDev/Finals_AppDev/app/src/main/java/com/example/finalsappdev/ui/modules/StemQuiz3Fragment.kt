package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class StemQuiz3Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "What branch of engineering deals with the design and construction of buildings?" to listOf("Mechanical Engineering", "Civil Engineering", "Electrical Engineering", "Chemical Engineering"),
        "What type of energy is primarily used in hydroelectric power plants?" to listOf("Solar", "Nuclear", "Kinetic", "Chemical"),
        "Which law states that 'For every action, there is an equal and opposite reaction'?" to listOf("Newton's First Law", "Newton's Second Law", "Newton's Third Law", "Law of Thermodynamics"),
        "What material is commonly used as a semiconductor in electronics?" to listOf("Copper", "Iron", "Silicon", "Gold"),
        "What is the main purpose of a bridge truss?" to listOf("Increase load capacity", "Improve aesthetics", "Reduce weight", "Prevent corrosion"),
        "Which of these is NOT a renewable energy source?" to listOf("Wind", "Coal", "Solar", "Hydroelectric"),
        "What is the process of joining metal parts using heat called?" to listOf("Welding", "Casting", "Forging", "Soldering"),
        "Which type of engineer designs aircraft and spacecraft?" to listOf("Mechanical Engineer", "Aerospace Engineer", "Chemical Engineer", "Civil Engineer"),
        "What is the purpose of a circuit breaker in an electrical system?" to listOf("Generate power", "Prevent overloading", "Store electricity", "Increase voltage"),
        "What manufacturing process is used to create 3D objects layer by layer?" to listOf("Injection Molding", "3D Printing", "CNC Machining", "Die Casting")
    )

    private val correctAnswers = listOf(1, 2, 2, 2, 0, 1, 0, 1, 1, 1)
    private var currentQuestionIndex = 0


    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "STEM Quiz 3"
        binding.backStrand.text = "Module 3: Engineering"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()

        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedRadioButtonId = binding.radioGroup.checkedRadioButtonId
        val selectedAnswerIndex = when (selectedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }


    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.STEMQ3_to_Score, bundle)
    }


    private fun calculateScore(): Int {
        var score = 0

        for (i in userAnswers.indices) {
            if (userAnswers[i] != -1) {
                if (userAnswers[i] == correctAnswers[i]) {
                    score++
                }
            }
        }

        return score
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
