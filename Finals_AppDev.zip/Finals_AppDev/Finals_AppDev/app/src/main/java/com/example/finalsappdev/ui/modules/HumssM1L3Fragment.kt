package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM1L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Arts and Culture"
        binding.lessontextView.text = "Lesson 3: Cultural Identity & Heritage"
        binding.readingContent.text = "Culture is a shared system of beliefs, customs, and traditions that define a society. It shapes how individuals interact, communicate, and express themselves."

        val heading = listOf(
            "Introduction",
            "Components of Culture",
            "Material Culture",
            "Non-Material Culture",
            "Cultural Heritage",
            "The Importance of Preserving Cultural Identity & Heritage",
            "Challenges in Preserving Cultural Heritage",
            "Balancing Tradition and Modernity"
        )
        val lessons = listOf(
            "Culture is the foundation of human identity. It is a shared system of beliefs, customs, values, traditions, and practices that define a society. Culture shapes how individuals think, behave, interact, and express themselves. It influences language, art, history, social norms, and even daily life. Through cultural identity, people develop a sense of belonging and connection to their communities, fostering unity and mutual respect.",
            "Culture is often divided into two main categories: Material Culture and Non-Material Culture.",
            "Material culture refers to the physical objects, artifacts, and tangible aspects that represent a society’s way of life. These items often reflect the technological advancements, craftsmanship, and artistic expressions of a culture. Examples include:\n" +
                    "\n" +
                    "Clothing and Fashion: Traditional attire such as the Japanese kimono, the Indian sari, or the Scottish kilt.\n" +
                    "Food and Cuisine: Different regions have unique dishes that define their culture, such as Italian pasta, Mexican tacos, or Japanese sushi.\n" +
                    "Architecture and Monuments: Historical buildings, temples, castles, and landmarks represent a society’s artistic and structural achievements (e.g., the Eiffel Tower, the Great Wall of China, the Pyramids of Egypt).\n" +
                    "Tools and Artifacts: Items such as pottery, weapons, farming tools, and handicrafts that reflect historical ways of living.",
            "Non-material culture consists of intangible aspects that shape social behavior and identity. These elements are deeply embedded in a society’s traditions and practices. Examples include:\n" +
                    "\n" +
                    "Language and Dialects: Language is one of the strongest identifiers of cultural identity. Many languages have regional dialects that carry unique expressions, idioms, and worldviews.\n" +
                    "Traditions and Customs: Rituals, ceremonies, and celebrations that are passed down through generations, such as weddings, religious festivals, and coming-of-age ceremonies (e.g., quinceañera in Latin America, Bar Mitzvah in Jewish culture).\n" +
                    "Values and Beliefs: Moral codes, ethical values, and philosophies that shape how people interact and make decisions.\n" +
                    "Social Norms and Practices: Expected behaviors and customs in a given culture, such as greetings, table manners, and respect for elders.",
            "Cultural heritage refers to the legacy of physical and intangible elements that define a community’s identity. It is what societies inherit from past generations and pass on to future ones. Cultural heritage can be classified into two major categories:\n" +
                    "\n" +
                    "a. Tangible Heritage\n" +
                    "Tangible heritage includes physical and material artifacts that hold historical or artistic significance. Examples include:\n" +
                    "\n" +
                    "Monuments and Historic Buildings: Castles, temples, mosques, and cathedrals that reflect architectural styles of different time periods.\n" +
                    "Archaeological Sites: Ruins of ancient civilizations, such as Machu Picchu in Peru or the Colosseum in Rome.\n" +
                    "Artifacts and Objects: Items such as paintings, sculptures, manuscripts, and pottery displayed in museums.\n" +
                    "b. Intangible Heritage\n" +
                    "Intangible heritage consists of non-physical cultural elements that define a community’s traditions and values. Examples include:\n" +
                    "\n" +
                    "Folklore and Mythology: Traditional stories, legends, and oral histories passed down through generations.\n" +
                    "Music and Dance: Traditional music, folk songs, and dances that reflect cultural identity (e.g., Flamenco in Spain, Taiko drumming in Japan).\n" +
                    "Religious Practices and Rituals: Spiritual beliefs and ceremonial traditions that shape a community’s way of life.\n" +
                    "Oral Traditions and Storytelling: The transmission of knowledge, values, and history through spoken word rather than written texts.",
            "Cultural identity and heritage play a crucial role in society, providing individuals with a sense of pride, continuity, and connection to their roots. Some key reasons for preserving cultural heritage include:\n" +
                    "\n" +
                    "a. Maintaining Cultural Diversity\n" +
                    "Each culture is unique, contributing to the richness of human civilization. Preserving different cultures ensures that traditions, languages, and knowledge systems are not lost over time.\n" +
                    "\n" +
                    "b. Strengthening National and Community Identity\n" +
                    "Cultural heritage fosters a sense of belonging among people. It strengthens national pride and helps communities stay connected to their past while shaping their future.\n" +
                    "\n" +
                    "c. Educating Future Generations\n" +
                    "Understanding cultural heritage helps younger generations learn about their history, traditions, and ancestral knowledge. It also teaches respect for other cultures, promoting global awareness and acceptance.\n" +
                    "\n" +
                    "d. Boosting Tourism and Economic Growth\n" +
                    "Cultural heritage sites attract tourists, generating economic opportunities for local communities. Many historical landmarks, museums, and cultural festivals contribute to a country’s economy.\n" +
                    "\n" +
                    "e. Promoting Social Cohesion and Inclusivity\n" +
                    "Recognizing and respecting diverse cultural identities encourages tolerance and mutual understanding among different communities. It helps combat discrimination and fosters unity.",
            "Despite its importance, cultural heritage faces various threats, including:\n" +
                    "\n" +
                    "a. Globalization and Cultural Erosion\n" +
                    "The spread of global influences can lead to the decline of local traditions, languages, and customs as people adopt more mainstream practices.\n" +
                    "\n" +
                    "b. Modernization and Urbanization\n" +
                    "Rapid urban development often leads to the destruction of historical sites, replacing them with modern buildings. Many traditional art forms and crafts are also disappearing due to industrialization.\n" +
                    "\n" +
                    "c. War and Conflict\n" +
                    "Armed conflicts and wars have resulted in the destruction of cultural landmarks, such as ancient temples and historical monuments.\n" +
                    "\n" +
                    "d. Climate Change and Natural Disasters\n" +
                    "Rising sea levels, earthquakes, and other environmental factors threaten heritage sites around the world. For example, coastal erosion endangers historic locations near the sea.",
            "While preserving cultural heritage is crucial, societies must also adapt to change. Modernization does not mean abandoning traditions; instead, it involves finding a balance between preserving the past and embracing progress. Some ways to achieve this balance include:\n" +
                    "\n" +
                    "Documenting and Digitizing Heritage: Using digital platforms, archives, and virtual museums to preserve cultural knowledge.\n" +
                    "Promoting Cultural Education: Schools and communities should integrate cultural studies into their curricula to ensure future generations understand their heritage.\n" +
                    "Encouraging Cultural Festivals and Events: Public celebrations of cultural traditions help keep them alive while making them accessible to younger generations.\n" +
                    "Supporting Indigenous and Local Communities: Recognizing and protecting the rights of indigenous groups and local artisans helps sustain traditional crafts and knowledge."
        )


        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
