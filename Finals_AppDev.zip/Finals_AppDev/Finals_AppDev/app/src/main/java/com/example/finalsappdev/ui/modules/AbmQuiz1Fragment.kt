package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class AbmQuiz1Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "What does ABM stand for?" to listOf(
            "Accounting and Business Management",
            "Applied Business Methods",
            "Accountancy, Business, and Management",
            "Advanced Business Marketing"
        ),
        "Which financial statement shows a company’s revenue and expenses?" to listOf(
            "Balance Sheet",
            "Income Statement",
            "Cash Flow Statement",
            "Statement of Changes in Equity"
        ),
        "What is the primary goal of marketing?" to listOf(
            "Maximize profits",
            "Increase brand awareness",
            "Satisfy customer needs",
            "Lower production costs"
        ),
        "Which of the following is a liability?" to listOf(
            "Accounts Payable",
            "Accounts Receivable",
            "Retained Earnings",
            "Inventory"
        ),
        "What is the first step in the business planning process?" to listOf(
            "Market Research",
            "Writing a Business Plan",
            "Setting Objectives",
            "Seeking Investors"
        ),
        "What does ROI stand for in business?" to listOf(
            "Rate of Investment",
            "Return on Investment",
            "Revenue over Income",
            "Return on Income"
        ),
        "Which marketing strategy focuses on building relationships with customers?" to listOf(
            "Transactional Marketing",
            "Digital Marketing",
            "Relationship Marketing",
            "Influencer Marketing"
        ),
        "What is an example of a fixed cost?" to listOf(
            "Raw Materials",
            "Electricity Bill",
            "Advertising Cost",
            "Office Rent"
        ),
        "Which department is responsible for hiring employees?" to listOf(
            "Sales",
            "Operations",
            "Human Resources",
            "Finance"
        ),
        "Which pricing strategy involves setting a low price to attract customers?" to listOf(
            "Premium Pricing",
            "Penetration Pricing",
            "Cost-Plus Pricing",
            "Competitive Pricing"
        )
    )

    private val correctAnswers = listOf(2, 1, 2, 0, 0, 1, 2, 3, 2, 1)
    private var currentQuestionIndex = 0
    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "ABM Quiz 1"
        binding.backStrand.text = "Module 1: Business Fundamentals"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()
        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedAnswerIndex = when (binding.radioGroup.checkedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }

    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.ABMQ1_to_Score, bundle)
    }

    private fun calculateScore(): Int {
        return userAnswers.count { it != -1 && it == correctAnswers[it] }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
