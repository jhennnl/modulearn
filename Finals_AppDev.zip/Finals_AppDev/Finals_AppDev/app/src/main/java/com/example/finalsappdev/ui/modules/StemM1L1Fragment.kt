package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM1L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Science"
        binding.lessontextView.text = "Lesson 1: Biology"
        binding.readingContent.text = "Biology is the scientific study of life. It focuses on understanding living organisms, from the smallest bacteria to the largest animals and plants."

        val lessons = listOf(
            "The cell is the fundamental building block of all living organisms. It is often referred to as the \"basic unit of life\" because it performs all the essential functions required for an organism's survival. Cells are responsible for processes such as metabolism, energy production, and reproduction. Every living organism, from single-celled bacteria to complex multicellular organisms like humans, is made up of cells.",
            "Plants use a process called photosynthesis to create their own food. This process occurs primarily in the chloroplasts of plant cells, where light energy from the sun is captured and used to convert carbon dioxide from the air and water from the soil into glucose (a type of sugar) and oxygen. This provides the energy needed for the plant to grow, develop, and carry out other essential functions.",
            "Red blood cells are a type of cell found in the blood. Their primary function is to carry oxygen from the lungs to the rest of the body and return carbon dioxide back to the lungs to be exhaled. These cells contain a protein called hemoglobin, which binds to oxygen and facilitates its transport through the bloodstream.",
            "The heart is a vital organ that serves as a pump to circulate blood throughout the body. It ensures that oxygen, nutrients, and other essential substances are transported to cells, while also removing waste products like carbon dioxide. The heart has four chambers and works in a rhythmic cycle to pump blood, maintaining blood flow and supporting life.",
            "The mitochondria are often referred to as the \"powerhouses\" of the cell. They are responsible for generating energy in the form of adenosine triphosphate (ATP) through a process known as cellular respiration. This energy is essential for the cell’s functions, growth, and maintenance. Without mitochondria, cells would not have the energy needed to perform their tasks.",
            "DNA (Deoxyribonucleic Acid) is the genetic material found in the nucleus of a cell. It contains the instructions that guide the cell’s functions and the development of an organism. DNA is made up of two strands that coil into a double helix structure. The information stored in DNA is passed from one generation to the next, ensuring the continuation of life.",
            "The skin is the largest organ in the human body, covering and protecting all internal organs. It serves as a barrier against harmful microorganisms, helps regulate body temperature, and allows the sensation of touch. The skin is also involved in the production of vitamin D and plays a key role in excretion through sweat.",
            "Cellular respiration is the process by which cells break down food (glucose) to produce energy. This process occurs in the mitochondria and involves the use of oxygen to convert glucose into ATP, which is used by the cell for various activities. Cellular respiration is essential for maintaining the functions of all living cells.",
            "The roots of a plant are responsible for absorbing water and nutrients from the soil. They anchor the plant in the ground and play a crucial role in the plant's ability to survive. Water and nutrients absorbed by the roots are transported up through the stem to the rest of the plant, supporting growth and development.",
            "Reproduction is the biological process by which organisms produce offspring, ensuring the continuation of their species. There are two main types of reproduction: sexual and asexual. Sexual reproduction involves the combination of genetic material from two parents, while asexual reproduction results in offspring that are genetically identical to the parent."
        )

        val heading = listOf(
            "The Basic Unit of Life: The Cell",
            "Photosynthesis: The Process of Food Production in Plants",
            "Red Blood Cells: Transporting Oxygen",
            "The Heart: Pumping Blood Throughout the Body",
            "Mitochondria: The Powerhouse of the Cell",
            "DNA: The Genetic Material",
            "The Skin: The Largest Organ in the Human Body",
            "Cellular Respiration: The Process of Energy Production",
            "Roots: Absorbing Water and Nutrients",
            "Reproduction: The Process of Producing Offspring"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemlesson1Fragment_to_stemModule1Fragment)
        }

        return binding.root
    }
}
