package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM1L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Arts and Culture"
        binding.lessontextView.text = "Lesson 2: Art Movements & Styles"
        binding.readingContent.text = "Art has continuously evolved across time, with various movements and styles reflecting cultural, historical, and philosophical shifts in human creativity."

        val heading = listOf(
            "Renaissance Art (14th–17th Century)",
            "Baroque (17th–18th Century)",
            "Modernism (19th–20th Century)",
            "Postmodernism (20th–21st Century)",
            "Romanticism",
            "Realism",
            "Impressionism & Post-Impressionism",
            "Surrealism & Dadaism",
            "Digital & Contemporary Art"
        )
        val lessons = listOf(
            "Focused on realism, humanism, and classical beauty. Artists used techniques like perspective and chiaroscuro to create lifelike representations of the human form. (e.g., Leonardo da Vinci’s Mona Lisa, Michelangelo’s David)",
            "Characterized by dramatic use of light, movement, and intense emotion, often tied to religious themes. (e.g., Caravaggio’s paintings, Bernini’s sculptures)",
            "Broke traditional artistic rules, emphasizing abstraction, emotion, and experimentation. This era rejected realism in favor of new forms and expressions. (e.g., Picasso’s Cubism, Van Gogh’s Post-Impressionism)",
            "Challenges artistic conventions, often incorporating mixed media, irony, and social commentary. It blurs boundaries between art forms and reality. (e.g., Andy Warhol’s Pop Art, Banksy’s street art)",
            "Emphasizing emotion, individualism, and nature (e.g., Francisco Goya, Caspar David Friedrich).",
            "Depicting everyday life with accuracy and detail (e.g., Gustave Courbet, Jean-François Millet).",
            "Innovations in color and light in painting (e.g., Monet, Van Gogh).",
            "The influence of dreams, the unconscious, and absurdity in art (e.g., Salvador Dalí, Marcel Duchamp).",
            "The impact of technology on modern artistic expression."
        )


        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
