package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentStrandBinding

class EnrolledStrandFragment : Fragment() {

    private var _binding: FragmentStrandBinding? = null
    private val binding get() = _binding!!
    private var selectedStrand: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStrandBinding.inflate(inflater, container, false)

        binding.strandAbm.setOnClickListener {
            selectedStrand = "ABM"
            showEnrollCancelButtons()
        }

        binding.strandHumss.setOnClickListener {
            selectedStrand = "HUMSS"
            showEnrollCancelButtons()
        }

        binding.strandStem.setOnClickListener {
            selectedStrand = "STEM"
            showEnrollCancelButtons()
        }

        binding.enrollBtn.setOnClickListener {
            when (selectedStrand) {
                "STEM" -> findNavController().navigate(R.id.enrolledStrand_to_STEM)
                "ABM" -> findNavController().navigate(R.id.enrolledStrand_to_ABM)
                "HUMSS" -> findNavController().navigate(R.id.enrolledStrand_to_HUMSS)
            }
        }

        binding.cancelBtn.setOnClickListener {
            hideEnrollCancelButtons()
            selectedStrand = null
        }

        return binding.root
    }

    private fun showEnrollCancelButtons() {
        binding.enrollBtn.visibility = View.VISIBLE
        binding.cancelBtn.visibility = View.VISIBLE
    }

    private fun hideEnrollCancelButtons() {
        binding.enrollBtn.visibility = View.GONE
        binding.cancelBtn.visibility = View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
