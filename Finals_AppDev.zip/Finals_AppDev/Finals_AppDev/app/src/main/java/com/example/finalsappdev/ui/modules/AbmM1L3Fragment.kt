package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM1L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Business Fundamentals"
        binding.lessontextView.text = "Lesson 3: Business Ethics"
        binding.readingContent.text = "Business ethics refers to moral principles that guide business decision-making and behavior."

        val lessons = listOf(
            "Corporate social responsibility (CSR) is a business approach that contributes to sustainable development.",
            "Transparency involves open communication and honesty in business operations.",
            "Fair trade ensures ethical sourcing and fair wages for workers.",
            "Consumer rights protect buyers from fraudulent or harmful business practices.",
            "Environmental sustainability focuses on reducing a company's ecological footprint."
        )

        val heading = listOf(
            "Corporate Social Responsibility (CSR)",
            "Transparency in Business",
            "Fair Trade: Ethical Sourcing",
            "Consumer Rights and Protection",
            "Environmental Sustainability"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
