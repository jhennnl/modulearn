package com.example.finalsappdev.ui.starting

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLoginBinding

class LoginFragment : Fragment() {
    private lateinit var binding: FragmentLoginBinding
    private lateinit var dbHelper: Database

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLoginBinding.inflate(inflater, container, false)
        dbHelper = Database(requireContext())

        requireActivity().findViewById<View>(R.id.nav_view)?.visibility = View.GONE

        binding.loginBtn.setOnClickListener {
            loginUser()
        }

        binding.signupBtn.setOnClickListener {
            findNavController().navigate(R.id.loginPage_to_signUp)
        }

        return binding.root
    }

    private fun loginUser() {
        val username = binding.usernameEditText.text.toString().trim()
        val password = binding.passwordEditText.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter both username and password.", Toast.LENGTH_SHORT).show()
            return
        }

        val user = dbHelper.getUser(username, password)
        if (user != null) {
            Toast.makeText(requireContext(), "Login Successful! Welcome ${user.firstName} ${user.lastName}", Toast.LENGTH_SHORT).show()

            val sharedPreferences = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            sharedPreferences.edit().apply {
                putString("firstName", user.firstName)
                putString("lastName", user.lastName)
                putString("username", user.username)
                apply()
            }

            val bundle = Bundle().apply {
                putString("firstName", user.firstName)
                putString("lastName", user.lastName)
            }
            findNavController().navigate(R.id.loginPage_to_Home, bundle)
        } else {
            Toast.makeText(requireContext(), "Login Failed! Invalid credentials.", Toast.LENGTH_SHORT).show()
        }
    }
}
