package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class StemModule1Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "STEM Module"
        binding.title.text = "Module 1: Science"

        imageList = arrayOf(
            R.drawable.biology,
            R.drawable.physics,
            R.drawable.atom,
            R.drawable.earthscience,
            R.drawable.spacescience
        )

        titleList = arrayOf(
            "Lesson 1: Biology",
            "Lesson 2: Physics",
            "Lesson 3: Chemistry",
            "Lesson 4: Earth Science",
            "Lesson 5: Space Science"
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                if (selectedItem.dataTitle == "Lesson 1: Biology") {
                    findNavController().navigate(R.id.STEM_M1_to_L1)
                }
                if (selectedItem.dataTitle == "Lesson 2: Physics") {
                    findNavController().navigate(R.id.STEM_M1_to_L2)
                }
                if (selectedItem.dataTitle == "Lesson 3: Chemistry") {
                    findNavController().navigate(R.id.STEM_M1_to_L3)
                }
                if (selectedItem.dataTitle == "Lesson 4: Earth Science") {
                    findNavController().navigate(R.id.STEM_M1_to_L4)
                }
                if (selectedItem.dataTitle == "Lesson 5: Space Science") {
                    findNavController().navigate(R.id.STEM_M1_to_L5)
                }
            }
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn_STEM_Module1_Return)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }

}
