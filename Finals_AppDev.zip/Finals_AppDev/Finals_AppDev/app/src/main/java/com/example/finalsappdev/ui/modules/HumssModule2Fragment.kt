package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class HumssModule2Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "Humss Module"
        binding.title.text = "Module 2: Philosophy and Society"

        imageList = arrayOf(
            R.drawable.ideas,
            R.drawable.ethics,
            R.drawable.politics
        )

        titleList = arrayOf(
            "Lesson 1: Major Philosophical Ideas",
            "Lesson 2: Ethics and Moral Dilemmas",
            "Lesson 3: Political System & Power"
        )


        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                if (selectedItem.dataTitle == "Lesson 1: Major Philosophical Ideas") {
                    findNavController().navigate(R.id.HUMSS_M2_to_L1)
                }
                if (selectedItem.dataTitle == "Lesson 2: Ethics and Moral Dilemmas") {
                    findNavController().navigate(R.id.HUMSS_M2_to_L2)
                }
                if (selectedItem.dataTitle == "Lesson 3: Political System & Power") {
                    findNavController().navigate(R.id.HUMSS_M2_to_L3)
                }
            }
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }

}