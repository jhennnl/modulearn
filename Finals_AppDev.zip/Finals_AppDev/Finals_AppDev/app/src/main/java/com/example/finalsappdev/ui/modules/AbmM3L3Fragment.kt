package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM3L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Financial Management"
        binding.lessontextView.text = "Lesson 3: Financial Statements and Analysis"
        binding.readingContent.text = "Financial statements are essential tools that businesses use to assess their financial health. They provide insights into a company's profitability, liquidity, and overall performance."

        val lessons = listOf(
            "The balance sheet provides a snapshot of a company’s financial position at a specific point in time. It includes assets (what the company owns), liabilities (what the company owes), and equity (owner’s investment). A well-balanced sheet ensures financial stability and liquidity.",
            "The income statement, also known as the profit and loss statement, shows a company’s financial performance over a period. It details revenues, expenses, and net profit or loss. Analyzing this statement helps businesses identify profitability trends and areas for cost reduction.",
            "The cash flow statement tracks the inflow and outflow of cash within a business. It consists of operating, investing, and financing activities. A positive cash flow ensures that a company can meet its short-term obligations and reinvest in growth.",
            "Financial ratios are key indicators used to analyze financial statements. These include liquidity ratios (to assess short-term financial health), profitability ratios (to measure earnings performance), and debt ratios (to evaluate financial risk).",
            "Break-even analysis helps businesses determine the point at which total revenue equals total costs. This calculation is essential for pricing strategies, budgeting, and financial forecasting to ensure profitability."
        )

        val heading = listOf(
            "Balance Sheet: Understanding Financial Position",
            "Income Statement: Measuring Profitability",
            "Cash Flow Statement: Tracking Money Movement",
            "Financial Ratios: Key Performance Indicators",
            "Break-even Analysis: Determining Profitability"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
