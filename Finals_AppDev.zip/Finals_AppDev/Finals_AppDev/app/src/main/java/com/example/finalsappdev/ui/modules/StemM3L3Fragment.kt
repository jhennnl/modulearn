package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM3L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Engineering"
        binding.lessontextView.text = "Lesson 3: Engineering Applications"
        binding.readingContent.text = "Engineering plays a vital role in modern life, influencing everything from communication to transportation. Many everyday items are the result of engineering innovations."

        val heading = listOf(
            "Everyday Items Made Possible by Engineering",
            "Civil Engineering in Daily Life",
            "Engineering and Bridge Construction",
            "Engineering in Medicine",
            "Engineering and Communication",
            "Renewable Energy in Engineering",
            "Engineering and Transportation",
            "Engineering in Environmental Conservation",
            "Engineering and Disaster Preparedness",
            "Famous Engineering Projects"
        )

        val lessons = listOf(
            "From the smartphone in your pocket to the electricity that powers your home, engineering is behind many of the essential technologies we rely on daily. Electrical engineers design circuits for electronic devices, while materials engineers develop durable materials. Without engineering, modern conveniences such as computers, cars, and medical devices would not exist. These advancements continue to evolve, making life more efficient and connected.",
            "Civil engineers design and maintain roads, bridges, buildings, and water systems. Their work ensures that cities function efficiently, providing clean water, stable transportation networks, and disaster-resistant structures. From skyscrapers to sewage systems, civil engineering touches nearly every aspect of our lives, making communities safer and more sustainable.",
            "Civil engineers specialize in designing bridges that withstand environmental conditions and heavy loads. They use physics and advanced materials to ensure stability and longevity. Suspension bridges, arch bridges, and beam bridges are just a few types of structures designed for specific terrains and needs. Engineering innovation has led to safer, longer-lasting bridges that enhance transportation worldwide.",
            "Biomedical engineers develop technologies such as surgical robots, MRI machines, and prosthetic limbs. These innovations enhance medical procedures and improve patient outcomes. Advancements like 3D-printed organs and robotic-assisted surgeries showcase how engineering continues to revolutionize healthcare, making treatments more precise and effective.",
            "From the printing press to the internet, engineering has played a central role in communication. Electrical and computer engineers develop technologies such as smartphones, fiber-optic networks, and satellites, enabling instant global connectivity. These innovations allow people to share information faster and more efficiently than ever before.",
            "Renewable energy sources such as solar power, wind energy, and hydroelectricity are designed to reduce dependence on fossil fuels. Engineers develop solar panels, wind turbines, and energy-efficient grids to harness natural energy efficiently. These efforts help combat climate change and promote environmental sustainability.",
            "Engineers design and improve vehicles, roads, railways, and air transport systems. Innovations such as electric cars, high-speed trains, and smart traffic management systems make transportation more reliable and environmentally friendly. These advancements enhance mobility, reduce travel time, and improve fuel efficiency.",
            "Environmental engineers develop technologies such as water purification systems, renewable energy sources, and waste management solutions. They also work on reducing pollution through innovations like carbon capture and sustainable urban planning. Engineering plays a crucial role in addressing climate change and preserving natural resources.",
            "Engineers design earthquake-resistant buildings, flood control systems, and emergency response technologies. Disaster preparedness includes early warning systems, durable infrastructure, and efficient evacuation plans. By applying engineering principles, societies can minimize damage and recover faster from disasters.",
            "Iconic engineering projects such as the Great Pyramid of Giza, the Panama Canal, and the International Space Station showcase human ingenuity. These projects required advanced planning, materials, and problem-solving skills. They highlight the impact of engineering on history, progress, and global development."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M3L3_to_M3)
        }

        return binding.root
    }
}