package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM3L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Psychology and Media"
        binding.lessontextView.text = "Lesson 1: Human Development"
        binding.readingContent.text = "Human development explores how people grow, think, and behave throughout life, shaped by biological, psychological, and social factors."

        val heading = listOf(
            "Introduction to Human Behavior",
            "The Stages of Human Development",
            "Cognitive Development and Learning",
            "Emotional and Social Development",
            "Personality and Identity Formation",
            "Mental Health and Human Behavior",
            "The Role of Motivation and Goal-Setting"
        )

        val lessons = listOf(
            "Why do people act the way they do? Psychologists study behavior to understand decision-making, emotions, and social interactions.\n" +
                    "\n" +
                    "Key influences include:\n" +
                    "\n" +
                    "Nature vs. Nurture: Are we shaped more by genetics or our environment?\n" +
                    "Social Conditioning: How society influences our behavior through norms and expectations.\n" +
                    "Understanding behavior helps improve relationships, work performance, and mental health.",
            "Psychologists like Erik Erikson and Jean Piaget outlined key stages of development:\n" +
                    "\n" +
                    "Infancy (0-2 years): Learning trust and attachment.\n" +
                    "Childhood (2-12 years): Developing basic skills and independence.\n" +
                    "Adolescence (13-19 years): Identity formation and emotional development.\n" +
                    "Adulthood (20+ years): Responsibility, relationships, and career growth.\n" +
                    "Each stage has challenges that shape our personality and future behavior.",
            "How do we learn and think? Cognitive psychology explores how people process information, solve problems, and make decisions.\n" +
                    "\n" +
                    "Jean Piaget’s Theory: Children develop through different stages of thinking.\n" +
                    "Memory & Intelligence: Why do we forget things? How does our brain store knowledge?\n" +
                    "Critical Thinking: How to make logical and informed decisions in daily life.\n" +
                    "Understanding cognitive development helps improve education and decision-making.",
            "Humans are emotional beings, and our feelings affect our actions.\n" +
                    "\n" +
                    "Emotional Intelligence (EQ): The ability to recognize and manage emotions.\n" +
                    "Empathy & Relationships: How we understand and connect with others.\n" +
                    "Social Influences: How peer pressure, family, and culture shape our personality.\n" +
                    "Learning emotional regulation is key to mental health and strong relationships.",
            "What makes you unique? Psychologists explore different personality types:\n" +
                    "\n" +
                    "The \"Big Five\" Personality Traits: Openness, Conscientiousness, Extraversion, Agreeableness, and Neuroticism.\n" +
                    "Identity Crisis: How life experiences shape who we are.\n" +
                    "Cultural Identity: The impact of traditions and society on self-perception.\n" +
                    "Personality affects career choices, friendships, and leadership potential.",
            "Mental health issues affect millions, influencing thoughts and behavior.\n" +
                    "\n" +
                    "Common Disorders: Anxiety, depression, bipolar disorder.\n" +
                    "Coping Mechanisms: How people deal with stress—healthy vs. unhealthy habits.\n" +
                    "The Role of Therapy & Counseling: How professional help can improve mental well-being.\n" +
                    "Understanding mental health reduces stigma and encourages supportive communities.",
            "Why do some people achieve success while others struggle?\n" +
                    "\n" +
                    "Intrinsic vs. Extrinsic Motivation: Are we motivated by passion or rewards?\n" +
                    "The Psychology of Habits: How small actions create long-term success.\n" +
                    "Delayed Gratification: Why patience leads to better outcomes (e.g., the \"Marshmallow Test\").\n" +
                    "Motivation is key in education, careers, and personal growth."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}