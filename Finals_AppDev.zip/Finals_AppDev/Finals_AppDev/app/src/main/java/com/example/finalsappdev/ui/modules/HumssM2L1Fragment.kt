package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM2L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Philosophy and Society"
        binding.lessontextView.text = "Lesson 1: Major Philosophical Ideas"
        binding.readingContent.text = "Metaphysics is the branch of philosophy that explores the nature of reality, existence, and what it means for something to be real. "

        val heading = listOf(
            "Metaphysics: The Nature of Reality",
            "Epistemology: The Theory of Knowledge",
            "Logic and Reasoning",
            "Existentialism and Human Freedom",
            "Utilitarianism and Consequentialism",
            "Deontology and Moral Duty",
            "Social Contract Theory",
            "The Mind-Body Problem"
        )
        val lessons = listOf(
            "What is the nature of existence? Is reality purely physical, or does it include non-physical entities like the mind or the soul?\n" +
                    "\n" +
                    "Idealism suggests that reality is fundamentally mental or spiritual. Plato, for example, argued that the physical world is only a shadow of a more real world of ideas.\n" +
                    "Materialism asserts that only matter and physical things exist, and consciousness arises from physical processes.\n" +
                    "Dualism, famously proposed by René Descartes, claims that the mind and body are separate entities.",
            "Epistemology is the study of knowledge—how we acquire it, what counts as true knowledge, and whether we can truly know anything at all.\n" +
                    "\n" +
                    "Rationalism (Descartes, Spinoza) argues that knowledge is gained through reason and logic.\n" +
                    "Empiricism (Locke, Hume) suggests that knowledge comes from sensory experience.\n" +
                    "Skepticism questions whether we can ever be certain of anything.",
            "Logic is the foundation of philosophical argumentation. It provides rules for constructing valid arguments and avoiding fallacies.\n" +
                    "\n" +
                    "Deductive reasoning: If the premises are true, the conclusion must also be true. (e.g., All humans are mortal. Socrates is a human. Therefore, Socrates is mortal.)\n" +
                    "Inductive reasoning: Conclusions are based on patterns or probabilities. (e.g., The sun has risen every day in recorded history, so it will rise tomorrow.)",
            "Existentialism focuses on individual freedom, choice, and the search for meaning.\n" +
                    "\n" +
                    "Jean-Paul Sartre argued that humans are \"condemned to be free,\" meaning we must create our own purpose without relying on external meaning.\n" +
                    "Friedrich Nietzsche declared that traditional values were collapsing, and people must redefine morality for themselves.\n" +
                    "Søren Kierkegaard emphasized personal faith and the \"leap of faith\" as necessary for finding meaning.",
            "Utilitarianism is an ethical theory that evaluates actions based on their consequences, specifically how much happiness or suffering they produce.\n" +
                    "\n" +
                    "Jeremy Bentham developed the \"greatest happiness principle\"—the right action is the one that maximizes happiness for the most people.\n" +
                    "John Stuart Mill refined this by distinguishing between higher (intellectual) and lower (physical) pleasures.",
            "Unlike utilitarianism, deontology argues that morality is based on duty and rules, not consequences.\n" +
                    "\n" +
                    "Immanuel Kant proposed the categorical imperative: An action is moral if it can be universally applied (e.g., if lying is wrong, then it’s wrong in all cases, regardless of the outcome).\n" +
                    "Deontology focuses on principles like honesty, justice, and human dignity rather than situational outcomes.",
            "Social contract theory explains the legitimacy of government and laws based on an agreement among people.\n" +
                    "\n" +
                    "Thomas Hobbes believed people surrender some freedoms in exchange for security, as life without government would be \"nasty, brutish, and short.\"\n" +
                    "John Locke argued that governments should protect natural rights (life, liberty, property), and if they fail, citizens have a right to revolt.\n" +
                    "Jean-Jacques Rousseau saw the social contract as a way to create a just society where people are truly free.\n" +
                    "This theory is fundamental to modern democracy and ideas about government legitimacy.",
            "The mind-body problem explores the relationship between the physical brain and conscious experience.\n" +
                    "\n" +
                    "Materialists believe consciousness is a product of brain activity.\n" +
                    "Dualists (like Descartes) argue that the mind is separate from the body.\n" +
                    "Panpsychists suggest that consciousness is a fundamental part of the universe, much like gravity.\n" +
                    "This question remains at the heart of debates in philosophy, neuroscience, and artificial intelligence."
        )


        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}