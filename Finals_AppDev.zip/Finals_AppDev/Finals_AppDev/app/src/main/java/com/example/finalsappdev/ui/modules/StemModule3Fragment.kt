package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class StemModule3Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "STEM Module"
        binding.title.text = "Module 3: Engineering"

        imageList = arrayOf(
            R.drawable.eng1,
            R.drawable.eng2,
            R.drawable.eng3,
        )

        titleList = arrayOf(
            "Lesson 1: Introduction to Engineering",
            "Lesson 2: Basic Engineering Design",
            "Lesson 3: Engineering Applications",
        )


        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                if (selectedItem.dataTitle == "Lesson 1: Introduction to Engineering") {
                    findNavController().navigate(R.id.stemM3_to_stemM3L1)
                }
                if (selectedItem.dataTitle == "Lesson 2: Basic Engineering Design") {
                    findNavController().navigate(R.id.stemM3_to_stemM3L2)
                }
                if (selectedItem.dataTitle == "Lesson 3: Engineering Applications") {
                    findNavController().navigate(R.id.stemM3_to_stemM3L3)
                }
            }
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemModule3Fragment_to_stemModuleFragment)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }

}
