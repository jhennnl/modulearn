package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class StemModule2Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "STEM Module"
        binding.title.text = "Module 2: Technology"

        imageList = arrayOf(
            R.drawable.cpu,
            R.drawable.software,
            R.drawable.technology,
        )

        titleList = arrayOf(
            "Lesson 1: Central Processing Unit",
            "Lesson 2: Programming Fundamentals",
            "Lesson 3: Emerging Technologies",
        )


        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                if (selectedItem.dataTitle == "Lesson 1: Central Processing Unit") {
                    findNavController().navigate(R.id.stemM2_to_stemM2L1)
                }
                if (selectedItem.dataTitle == "Lesson 2: Programming Fundamentals") {
                    findNavController().navigate(R.id.stemM2_to_stemM2L2)
                }
                if (selectedItem.dataTitle == "Lesson 3: Emerging Technologies") {
                    findNavController().navigate(R.id.stemM2_to_stemM2L3)
                }
            }
        }


        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemModule2Fragment_to_stemModuleFragment)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }

}
