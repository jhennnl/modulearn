package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM1L4Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Introduction to Business"
        binding.lessontextView.text = "Lesson 4: Financial Literacy"
        binding.readingContent.text = "Financial literacy is the ability to understand and effectively use various financial skills, including personal financial management, budgeting, and investing."

        val lessons = listOf(
            "Budgeting is the process of creating a plan to spend your money wisely.",
            "Savings accounts help individuals store money securely while earning interest.",
            "Investing involves putting money into financial assets to generate profits over time.",
            "Debt management is important for maintaining good financial health and avoiding excessive loans.",
            "Understanding taxes helps individuals and businesses comply with financial regulations."
        )

        val heading = listOf(
            "Budgeting: Managing Your Finances",
            "Savings: Securing Your Money",
            "Investing: Growing Your Wealth",
            "Debt Management: Avoiding Financial Struggles",
            "Taxes: Understanding Financial Obligations"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
