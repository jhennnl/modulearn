package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM4L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Marketing Management"
        binding.lessontextView.text = "Lesson 2: Market Research"
        binding.readingContent.text = "Market research is the process of gathering and analyzing information about consumers, competitors, and market trends to make informed business decisions"

        val lessons = listOf(
            "Market research helps businesses understand customer preferences, industry trends, and potential demand for products or services. It involves collecting data through surveys, interviews, and online research.",
            "Primary research involves gathering new data directly from consumers through methods such as surveys, focus groups, and interviews. This provides firsthand insights into customer needs and preferences.",
            "Secondary research involves analyzing existing data from sources such as industry reports, government publications, and competitor analysis. It helps businesses understand market trends and industry benchmarks.",
            "Competitive analysis involves identifying direct and indirect competitors, studying their strengths and weaknesses, and understanding their marketing strategies. This helps businesses position themselves effectively in the market.",
            "SWOT analysis (Strengths, Weaknesses, Opportunities, and Threats) is a strategic planning tool that helps businesses assess internal capabilities and external challenges. It guides decision-making for competitive advantage."
        )

        val heading = listOf(
            "Market Research: Understanding Consumer Needs",
            "Primary Research: Collecting Direct Customer Insights",
            "Secondary Research: Using Existing Market Data",
            "Competitive Analysis: Studying Business Rivals",
            "SWOT Analysis: Evaluating Business Strengths and Weaknesses"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
