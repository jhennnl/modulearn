package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM3L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Engineering"
        binding.lessontextView.text = "Lesson 2: Basic Engineering Design"
        binding.readingContent.text = "Basic engineering design is the process of creating a plan for an engineering project by defining technical concepts, gathering data, and developing designs."

        val heading = listOf(
            "The Engineering Design Process",
            "Brainstorming in Engineering Design",
            "The Importance of Defining the Problem",
            "Understanding Constraints in Engineering Design",
            "Material Constraints in Engineering",
            "The Purpose of Sketching and Blueprinting",
            "The Role of Prototyping",
            "Optimization in Engineering Design",
            "Creativity in Engineering Design",
            "Common Tools in Engineering Design"
        )

        val lessons = listOf(
            "The engineering design process is a structured approach engineers use to develop solutions. The first step is defining the problem—clearly identifying what needs to be solved before any design work begins. This step ensures that the solution effectively addresses the issue at hand.",
            "Brainstorming is a crucial part of the design process. It is a collaborative ideation session where multiple solutions are generated. Unlike analyzing a single solution, brainstorming encourages creativity and innovation to find the best possible approach.",
            "Clearly defining the problem ensures that the solution is directly aligned with the issue being addressed. Without a clear problem statement, the design process may become inefficient or ineffective.",
            "A constraint is a limitation or restriction placed on a design. Constraints can include:\n" +
                    "\n" +
                    "Material constraints: Limits on what materials can be used.\n" +
                    "\n" +
                    "Budget constraints: Financial limitations for the project.\n" +
                    "\n" +
                    "Time constraints: Deadlines for completion.",
            "An example of a material constraint is the required weight limit of a component. This limitation influences material selection and design choices to ensure functionality and safety.",
            "Creating sketches or blueprints is an essential step in engineering design. These visual representations help communicate the design and its specifications before production begins.",
            "Testing a prototype is an essential step in engineering. It allows engineers to identify and correct design flaws before final production, reducing errors and improving performance.",
            "Optimization is the process of improving a design to achieve the best performance within given constraints. Engineers refine designs to enhance efficiency, functionality, and cost-effectiveness.",
            "Creativity is a key factor in engineering. It helps generate innovative and effective solutions that go beyond traditional approaches.",
            "One of the most commonly used tools in engineering design is Computer-Aided Design (CAD) software. CAD software helps engineers create detailed 2D and 3D models of their designs, allowing for precise planning and modifications."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M3L2_to_M3)
        }

        return binding.root
    }
}