package com.example.finalsappdev.ui.modules

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.finalsappdev.R

class adapterClass2(
    private val dataList: ArrayList<dataClass2>,
    private val clickListener: (dataClass2, Boolean) -> Unit
) : RecyclerView.Adapter<adapterClass2.ViewHolderClass>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderClass {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_layout2, parent, false)
        return ViewHolderClass(itemView)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: ViewHolderClass, position: Int) {
        val currentItem = dataList[position]
        holder.rvImage.setImageResource(currentItem.dataImage)
        holder.rvTitle.text = currentItem.dataTitle
        holder.rvContext.text = currentItem.dataContext

        holder.itemView.setOnClickListener {
            clickListener(currentItem, false)
        }

        holder.quizButton.setOnClickListener {
            clickListener(currentItem, true)
        }
    }

    class ViewHolderClass(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val rvImage: ImageView = itemView.findViewById(R.id.image)
        val rvTitle: TextView = itemView.findViewById(R.id.title1)
        val quizButton: Button = itemView.findViewById(R.id.button)
        val rvContext: TextView = itemView.findViewById(R.id.title2)
    }
}
