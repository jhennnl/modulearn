package com.example.finalsappdev.ui.starting

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Database (context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UserDatabase.db"
        private const val DATABASE_VERSION = 2
        private const val TABLE_NAME = "users"
        private const val COLUMN_ID = "id"
        private const val COLUMN_FIRSTNAME = "first_name"
        private const val COLUMN_LASTNAME = "last_name"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_FIRSTNAME TEXT, " +
                "$COLUMN_LASTNAME TEXT, " +
                "$COLUMN_USERNAME TEXT UNIQUE, " +
                "$COLUMN_PASSWORD TEXT, " +
                "is_admin INTEGER DEFAULT 0)")
        db?.execSQL(createTableQuery)

        val insertAdminQuery = "INSERT INTO $TABLE_NAME ($COLUMN_FIRSTNAME, $COLUMN_LASTNAME, $COLUMN_USERNAME, $COLUMN_PASSWORD, is_admin) " +
                "VALUES ('Admin', 'User', 'admin', 'admin123', 1)"
        db?.execSQL(insertAdminQuery)
    }



    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db?.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN is_admin INTEGER DEFAULT 0")
        }
    }


    fun insertUser(firstName: String, lastName: String, username: String, password: String, isAdmin: Boolean = false): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_FIRSTNAME, firstName)
            put(COLUMN_LASTNAME, lastName)
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
            put("is_admin", if (isAdmin) 1 else 0)
        }

        return try {
            val result = db.insert(TABLE_NAME, null, values)
            db.close()
            result != -1L
        } catch (e: Exception) {
            db.close()
            false
        }


}
    fun getAllUsers(): List<String> {
        val users = mutableListOf<String>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT $COLUMN_USERNAME FROM $TABLE_NAME", null)

        if (cursor.moveToFirst()) {
            do {
                val username = cursor.getString(0)
                users.add(username)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return users
    }
    fun deleteUser(username: String): Boolean {
        val db = writableDatabase
        val result = db.delete(TABLE_NAME, "$COLUMN_USERNAME = ?", arrayOf(username))
        db.close()
        return result > 0
    }


    fun getUser(username: String, password: String): User? {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)
        val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)

        return cursor.use {
            if (it.moveToFirst()) {
                val firstName = it.getString(it.getColumnIndexOrThrow(COLUMN_FIRSTNAME))
                val lastName = it.getString(it.getColumnIndexOrThrow(COLUMN_LASTNAME))
                val isAdmin = it.getInt(it.getColumnIndexOrThrow("is_admin")) == 1
                User(firstName, lastName, username, isAdmin)
            } else {
                null
            }
        }
    }



    data class User(val firstName: String, val lastName: String, val username: String, val isAdmin: Boolean)


}

