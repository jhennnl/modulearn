package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM1L5Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Introduction to Business"
        binding.lessontextView.text = "Lesson 5: Entrepreneurship Basics"
        binding.readingContent.text = "Entrepreneurship is the process of starting and managing a business venture to make a profit while taking financial risks."

        val lessons = listOf(
            "Entrepreneurs identify business opportunities and create innovative solutions.",
            "A business plan outlines the vision, goals, and strategies of a startup.",
            "Marketing helps businesses reach their target audience and promote their products.",
            "Customer service is crucial for building relationships and retaining customers.",
            "Risk management helps entrepreneurs identify and mitigate potential business threats."
        )

        val heading = listOf(
            "Entrepreneurs: Innovators of the Market",
            "Business Plans: Roadmaps to Success",
            "Marketing: Promoting Your Business",
            "Customer Service: Building Loyalty",
            "Risk Management: Handling Business Challenges"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
