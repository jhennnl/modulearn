package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM4L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Mathematics"
        binding.lessontextView.text = "Lesson 1: Algebra"
        binding.readingContent.text = "Algebra is a fundamental branch of mathematics that deals with symbols and the rules for manipulating those symbols."

        val heading = listOf(
            "Solving for X",
            "Simplifying Expressions",
            "Factorization",
            "Understanding Slope",
            "Solving Equations",
            "Adding and Simplifying Algebraic Expressions",
            "Evaluating Expressions",
            "Expanding Binomials",
            "Solving Fractional Equations",
            "Applying Algebraic Rules"
        )

        val lessons = listOf(
            "Example: Solve 3x + 7 = 19\n" +
                    "\n" +
                    "Subtract 7 from both sides: 3x = 12\n" +
                    "\n" +
                    "Divide by 3: x = 4",
            "Example: Simplify 5b + 3b – 6\n" +
                    "\n" +
                    "Combine like terms: 8b – 6",
            "Example: Factorize y² – 16\n" +
                    "\n" +
                    "Recognize as a difference of squares: (y – 4)(y + 4)",
            "Example: Find the slope of y = 4x + 9\n" +
                    "\n" +
                    "The slope m is 4",
            "Example: Solve 7x = 35\n" +
                    "\n" +
                    "Divide both sides by 7: x = 5",
            "Example: Simplify (3x + 5) + (2x – 7)\n" +
                    "\n" +
                    "Combine like terms: 5x – 2",
            "Example: Find Z when Z = 3x + 2 and x = 4\n" +
                    "\n" +
                    "Substitute x = 4: Z = 3(4) + 2 = 14",
            "Example: Expand (x + 4)(x + 3)\n" +
                    "\n" +
                    "Apply distributive property: x² + 7x + 12",
            "Example: Solve y/5 = 6\n" +
                    "\n" +
                    "Multiply both sides by 5: y = 30",
            "Example: If p = 3 and q = 4, find pq + q\n" +
                    "\n" +
                    "Multiply and add: (3 × 4) + 4 = 16"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M4L1_to_M4)
        }

        return binding.root
    }
}