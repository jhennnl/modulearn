package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class HumssQuiz2Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "Which philosopher is known for the statement \"I think, therefore I am\"?" to listOf("Aristotle", "Descartes", "Plato", "Kant"),
        "The idea that reality is fundamentally mental rather than material is known as:" to listOf("Materialism", "Empiricism", "Idealism", "Rationalism"),
        "A major ethical concern in artificial intelligence is:" to listOf("The ability of AI to outperform humans in video games", "The risk of job automation and bias in decision-making", "The need for AI to have emotions", "The inability of AI to store large amounts of data"),
        "Which ethical principle supports the right of terminally ill patients to choose euthanasia?" to listOf("Deontology", "Autonomy", "Utilitarianism", "Legalism"),
        "A company engaging in false advertising is violating which ethical principle?" to listOf("Honesty and consumer trust", "Freedom of speech", "Market competition", "Maximization of profit"),
        "In the trolley problem, deontologists argue that:" to listOf("The morality of an action is based on its consequences", "It is always wrong to intentionally kill, even to save more lives", "The most ethical choice is based on personal emotions", "Whichever decision benefits society the most should be chosen"),
        "What is a major criticism of utilitarianism?" to listOf("It ignores the consequences of actions", "It is too focused on individual rights rather than the greater good", "It can justify morally questionable actions if they produce the best outcome", "It rejects all forms of rational thought"),
        "Which philosophy argues that nature has value beyond human use?" to listOf("Anthropocentrism", "Deep Ecology", "Hedonism", "Capitalism"),
        "Which of the following is an ethical issue in advertising?" to listOf("Misleading claims and manipulation of consumers", "Offering discounts to loyal customers", "Spending money on creative marketing", "Using social media for promotion"),
        "Collateral damage refers to:" to listOf("Unintended harm to civilians or property during war", "The amount of money spent on military equipment", "The time it takes to win a war", "The strategy of a country in battle")
    )

    private val correctAnswers = listOf(1, 2, 1, 1, 0, 1, 2, 1, 0, 0)
    private var currentQuestionIndex = 0
    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "HUMSS Quiz 2"
        binding.backStrand.text = "Module 2: Philosophy and Society"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()
        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedAnswerIndex = when (binding.radioGroup.checkedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }

    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.HUMSSQ2_to_Score, bundle)
    }

    private fun calculateScore(): Int {
        return userAnswers.count { it != -1 && it == correctAnswers[it] }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}