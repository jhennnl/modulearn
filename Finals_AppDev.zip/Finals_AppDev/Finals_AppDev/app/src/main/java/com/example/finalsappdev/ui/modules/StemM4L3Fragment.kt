package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM4L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Mathematics"
        binding.lessontextView.text = "Lesson 3: Geometry"
        binding.readingContent.text = "Geometry is the study of shapes, sizes, and properties of figures. It helps us understand spatial relationships and solve real-world problems. "

        val heading = listOf(
            "Area of a Rectangle",
            "Perimeter of a Square",
            "Angles in a Triangle",
            "Area of a Triangle",
            "Circumference of a Circle",
            "Identifying a Square",
            "Volume of a Cube",
            "Area of a Parallelogram"
        )

        val lessons = listOf(
            "A rectangle has opposite sides that are equal. The area is calculated using the formula:\n" +
                    "Area=length×width\n" +
                    "This helps determine the space a rectangle covers.",
            "A square has four equal sides. Its perimeter (the total distance around the shape) is given by:\n" +
                    "Perimeter=4×side\n" +
                    "This is useful when measuring borders or fences.",
            "Every triangle's interior angles sum up to 180°. In an equilateral triangle, all sides and angles are equal, with each angle measuring 60°.",
            "To find a triangle's area, use the formula:\n" +
                    "Area = 1/2 × base × height\n" +
                    "This helps in calculating land areas and structural designs.",
            "The circumference (distance around a circle) is found using:\n" +
                    "Circumference=2πr\n" + "where" + "r is the radius. \n \nThe diameter is twice the radius:\n" +
                    "Diameter=2×radius",
            "A square is a four-sided shape with equal sides and 90° angles. Unlike rectangles, all sides are identical in length.",
            "A cube has equal sides and three dimensions. The volume, which measures space inside, is given by:\n" +
                    "Volume=side × side × side",
            "A parallelogram has opposite sides that are parallel. Its area follows the formula:\n" +
                    "Area=base×height\n" +
                    "This is useful in floor tiling and construction projects."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M4L1_to_M4)
        }

        return binding.root
    }
}