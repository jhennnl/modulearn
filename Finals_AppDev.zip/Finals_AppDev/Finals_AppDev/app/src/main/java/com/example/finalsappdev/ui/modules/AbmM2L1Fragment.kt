package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM2L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Business Planning"
        binding.lessontextView.text = "Lesson 1: Introduction to Business Planning"
        binding.readingContent.text = "Business planning is the process of outlining the vision, mission, objectives, and strategies of a business."

        val lessons = listOf(
            "A business plan is a formal document that outlines the goals and strategies of a business.",
            "Market research involves gathering and analyzing data about customers and competitors.",
            "A SWOT analysis identifies the Strengths, Weaknesses, Opportunities, and Threats of a business.",
            "Financial projections estimate future revenue, costs, and profitability.",
            "A business model explains how a company creates, delivers, and captures value."
        )

        val heading = listOf(
            "Business Plan: The Roadmap to Success",
            "Market Research: Understanding the Market",
            "SWOT Analysis: Strengths and Weaknesses",
            "Financial Projections: Estimating Profitability",
            "Business Model: How a Business Operates"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
