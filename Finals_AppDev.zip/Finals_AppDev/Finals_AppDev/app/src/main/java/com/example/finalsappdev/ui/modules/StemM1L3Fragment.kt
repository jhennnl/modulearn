package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM1L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Science"
        binding.lessontextView.text = "Lesson 3: Chemistry"
        binding.readingContent.text = "Chemistry is the study of matter, its properties, and the changes it undergoes. Everything around us, from the air we breathe to the food we eat, is composed of chemical substances."

        val heading = listOf(
            "Atoms and Elements",
            "Chemical Bonds and Compounds",
            "States of Matter and Changes",
            "Acids, Bases, and pH",
            "Electric Charge and Subatomic Particles"
        )

        val lessons = listOf(
            "An atom is the smallest particle of an element that retains its chemical properties. Atoms combine to form molecules and compounds. Elements are organized in the periodic table, which classifies them based on their properties and atomic structure. Each element consists of only one type of atom.",
            "Elements can bond together to form compounds. In water (H₂O), two hydrogen atoms share electrons with an oxygen atom through a covalent bond, where electrons are shared between atoms. Another example is table salt (NaCl), which forms through an ionic bond, where electrons are transferred between atoms.",
            "Matter exists in different states: solid, liquid, gas, and plasma. A liquid has a definite volume but takes the shape of its container. Matter can change states through processes like vaporization, where a liquid turns into a gas, and condensation, where a gas turns into a liquid.",
            "The pH scale measures the acidity or alkalinity of a substance, ranging from 0 to 14. A neutral solution, like pure water, has a pH of 7. Acids have a pH below 7, while bases have a pH above 7. Understanding pH is essential in chemistry, biology, and environmental science.",
            "Atoms are made up of protons, neutrons, and electrons. Protons have a positive charge (+1), neutrons have no charge (0), and electrons have a negative charge (-1). Electrons play a crucial role in chemical bonding and electrical conductivity."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemlesson3Fragment_to_stemModule1Fragment)
        }

        return binding.root
    }
}
