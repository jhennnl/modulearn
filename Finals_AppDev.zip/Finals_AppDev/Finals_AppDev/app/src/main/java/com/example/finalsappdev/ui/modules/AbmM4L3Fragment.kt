package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM4L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Marketing Management"
        binding.lessontextView.text = "Lesson 3: Product Development"
        binding.readingContent.text = "Product development involves the process of designing, creating, and introducing new products to the market. "

        val lessons = listOf(
            "Product development includes idea generation, market analysis, prototyping, testing, and product launch. Businesses must ensure that new products meet customer needs and stand out from competitors.",
            "A successful brand has a clear identity, mission, and value proposition. Companies create strong branding through logos, slogans, colors, and brand messaging that reflect their uniqueness and reliability.",
            "Positioning a product in the market involves identifying its competitive advantage and targeting the right audience. Effective positioning highlights what makes the product different and why consumers should choose it.",
            "Customer perception influences purchasing decisions. Businesses must maintain a consistent brand image, deliver quality products, and engage with customers to build trust and loyalty.",
            "Successful product launches require strong marketing campaigns, social media presence, and customer engagement strategies. Businesses use promotions, advertising, and events to introduce products effectively."
        )

        val heading = listOf(
            "The Process of Product Development",
            "Building a Strong Brand Identity",
            "Market Positioning: Standing Out from Competitors",
            "Consumer Perception: Creating Brand Loyalty",
            "Effective Product Launch Strategies"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
