package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM1L4Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Science"
        binding.lessontextView.text = "Lesson 4: Earth Science"
        binding.readingContent.text = "Earth Science is the study of the Earth’s structure, processes, and systems. It explores how natural forces shape our planet and influence our environment."

        val heading = listOf(
            "Layers of the Earth",
            "Rocks and the Rock Cycle",
            "Earth’s Dynamic Processes",
            "Volcanoes and Earthquakes",
            "The Water Cycle",
            "Oceans and Fossils"
        )

        val lessons = listOf(
            "The Earth is made up of several layers. The crust is the outermost layer, composed of solid rock and forming continents and ocean floors. Beneath it is the mantle, a thick layer of semi-solid rock. The outer core is a layer of molten iron and nickel, while the inner core is a dense, solid metal sphere.",
            "Rocks on Earth are classified into three types:\n" +
                    "\n" +
                    "Igneous rocks form from cooled lava or magma.\n" +
                    "Sedimentary rocks are created from compacted sediments.\n" +
                    "Metamorphic rocks develop from existing rocks undergoing heat and pressure.\n" +
                    "Over time, rocks break down through weathering, where natural forces like wind and water wear them away. The rock cycle describes how rocks transform from one type to another through various geological processes.",
            "Earth is constantly changing due to natural forces. Tectonic plate movement causes earthquakes and volcanic eruptions. The shifting of these plates leads to the formation of mountains, valleys, and ocean trenches.",
            "Beneath the Earth's surface, molten rock is known as magma. When it erupts from a volcano, it becomes lava, which cools and hardens into igneous rock. Earthquakes occur when tectonic plates shift suddenly, releasing energy in the form of seismic waves.",
            "Water moves continuously through the water cycle, which involves evaporation, condensation, precipitation, and collection. This cycle ensures that water circulates between the atmosphere, land, and oceans, supporting life on Earth.",
            "The Pacific Ocean is the largest ocean on Earth, covering more area than all the continents combined. Oceans play a vital role in climate regulation and marine biodiversity. Scientists called paleontologists study fossils, which provide clues about past life forms and Earth's history."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemlesson4Fragment_to_stemModule1Fragment)
        }

        return binding.root
    }
}