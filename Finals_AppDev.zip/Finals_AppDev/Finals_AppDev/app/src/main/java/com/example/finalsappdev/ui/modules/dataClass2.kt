package com.example.finalsappdev.ui.modules

data class dataClass2(
    var dataImage: Int,
    var dataTitle: String,
    var quizFragment: Int,
    var dataContext: String
)
