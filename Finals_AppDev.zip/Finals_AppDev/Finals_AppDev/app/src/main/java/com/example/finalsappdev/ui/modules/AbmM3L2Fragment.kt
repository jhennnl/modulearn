package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM3L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Financial Management"
        binding.lessontextView.text = "Lesson 2: Understanding Business Loans"
        binding.readingContent.text = "Business loans and financing are essential for companies to fund operations, expand, and invest in new opportunities. "

        val lessons = listOf(
            "A business loan is a borrowed amount of money that a company repays with interest over time. Loans provide capital for startups, expansion, inventory, or operational costs. Understanding the terms, interest rates, and repayment schedules is crucial before taking a loan.",
            "Short-term loans are used for immediate financial needs and typically have a repayment period of less than a year. Businesses use them to cover temporary cash flow shortages, urgent inventory purchases, or unexpected expenses.",
            "Long-term loans are borrowed for several years and are used for major business investments, such as purchasing property, expanding operations, or upgrading technology. These loans have lower monthly payments but require businesses to commit to long-term repayment plans.",
            "Equity financing involves raising capital by selling shares of the company to investors. Unlike loans, businesses don’t have to repay the money, but investors gain ownership and may have a say in company decisions.",
            "Debt financing refers to borrowing money from financial institutions with the promise of repayment, usually with interest. Businesses must carefully balance debt to ensure they do not overborrow and struggle with repayments."
        )

        val heading = listOf(
            "Business Loans: Borrowing Capital",
            "Short-Term Loans: Quick Financial Support",
            "Long-Term Loans: Investing in Growth",
            "Equity Financing: Raising Funds by Selling Shares",
            "Debt Financing: Managing Borrowed Money"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
