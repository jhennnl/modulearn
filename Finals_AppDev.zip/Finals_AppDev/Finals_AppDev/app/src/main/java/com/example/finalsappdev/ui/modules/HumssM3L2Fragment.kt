package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM3L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Psychology and Media"
        binding.lessontextView.text = "Lesson 2: Media & Public Influence"
        binding.readingContent.text = " Media plays a powerful role in shaping public opinion, influencing societal norms, and controlling the flow of information, making media literacy essential in the digital age."

        val heading = listOf(
            "The Power of Media in Society",
            "Fake News and Misinformation",
            "Social Media and Public Opinion",
            "Advertising and Consumer Psychology",
            "Journalism and Media Ethics",
            "Propaganda and Political Influence",
            "Media Literacy: Thinking Critically About Information"
        )

        val lessons = listOf(
            "Media—news, social media, television, and advertising—shapes how we see the world. It influences:\n" +
                    "\n" +
                    "Public Opinion: How news coverage changes political views.\n" +
                    "Cultural Trends: How movies, music, and celebrities impact society.\n" +
                    "Consumer Behavior: How advertisements persuade us to buy products.\n" +
                    "Media can educate or mislead, making critical thinking essential.",
            "Not all news is accurate. Misinformation spreads fast, especially online.\n" +
                    "\n" +
                    "Clickbait & Sensationalism: How exaggerated headlines grab attention.\n" +
                    "Deepfakes & AI Manipulation: How technology creates false realities.\n" +
                    "Fact-Checking Strategies: How to verify credible sources.\n" +
                    "Being aware of media manipulation helps people avoid being misled.",
            "Platforms like Facebook, Twitter, and TikTok influence how people think.\n" +
                    "\n" +
                    "Echo Chambers: People are exposed only to views they already agree with.\n" +
                    "Cancel Culture: Public shaming for controversial opinions.\n" +
                    "Viral Trends: How social movements gain traction.\n" +
                    "Social media has the power to bring change but can also spread division.",
            "Why do we buy what we buy? Advertisers use psychological tricks to influence spending.\n" +
                    "\n" +
                    "Emotional Appeal: Ads make people feel happy, sad, or nostalgic.\n" +
                    "Fear Tactics: Some ads make people feel insecure (e.g., beauty industry).\n" +
                    "Brand Loyalty: Why people prefer Apple over Samsung, Coke over Pepsi.\n" +
                    "Recognizing these tactics helps consumers make smarter choices.",
            "Media has a responsibility to report the truth, but ethical concerns arise:\n" +
                    "\n" +
                    "Sensationalism: Overhyping stories for views.\n" +
                    "Bias in Reporting: Some media outlets favor one political side.\n" +
                    "Privacy Issues: When does journalism invade personal lives?\n" +
                    "Ethical journalism is essential for democracy and informed citizens.",
            "Governments and politicians use media to shape public perception.\n" +
                    "\n" +
                    "Historical Examples: Nazi propaganda, Cold War messaging.\n" +
                    "Modern Day: Political ads, social media campaigns.\n" +
                    "Manipulation Tactics: Repetition, emotional appeals, misinformation.\n" +
                    "Understanding propaganda helps people critically evaluate political messages.",
            "To navigate the media world, people must develop critical thinking skills:\n" +
                    "\n" +
                    "Recognizing Bias: Understanding different perspectives.\n" +
                    "Checking Sources: Identifying reliable vs. unreliable news.\n" +
                    "Understanding Persuasive Techniques: Questioning what media wants you to believe.\n" +
                    "Media literacy is key in the digital age.\n"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}