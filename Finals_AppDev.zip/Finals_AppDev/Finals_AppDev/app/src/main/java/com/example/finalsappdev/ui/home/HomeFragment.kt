package com.example.finalsappdev.ui.home

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        val firstNameFromArgs = arguments?.getString("firstName")

        val sharedPreferences = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val firstNameFromPrefs = sharedPreferences.getString("firstName", "User")

        val displayName = firstNameFromArgs ?: firstNameFromPrefs ?: "User"

        println("HomeFragment received: firstNameFromArgs=$firstNameFromArgs, firstNameFromPrefs=$firstNameFromPrefs")

        binding.welcomeBox.text = "Welcome to ModuLearn, $displayName. Let’s start building your learning journey today!"

        binding.humssLayout.setOnClickListener {
            showStrandInfo("HUMSS", "Humanities and Social Sciences (HUMSS) focuses on communication, social sciences, and humanities, preparing students for careers in law, journalism, psychology, and more.", R.drawable.social_science1)
        }

        binding.stemLayout.setOnClickListener {
            showStrandInfo("STEM", "Science, Technology, Engineering, and Mathematics (STEM) focuses on scientific and technical subjects, preparing students for careers in medicine, engineering, IT, and more.", R.drawable.mathematics1)
        }

        binding.abmLayout.setOnClickListener {
            showStrandInfo("ABM", "Accountancy, Business, and Management (ABM) focuses on business principles, entrepreneurship, and finance, preparing students for careers in business, marketing, and management.", R.drawable.accountingicon)
        }

        return binding.root
    }

    private fun showStrandInfo(title: String, description: String, imageResId: Int) {
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_design)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val icon = dialog.findViewById<ImageView>(R.id.placeholder)
        val titleText = dialog.findViewById<TextView>(R.id.dialog_title)
        val descriptionText = dialog.findViewById<TextView>(R.id.dialog_message)
        val closeButton = dialog.findViewById<Button>(R.id.dialog_button)

        icon.setImageResource(imageResId)
        titleText.text = title
        descriptionText.text = description

        closeButton.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
