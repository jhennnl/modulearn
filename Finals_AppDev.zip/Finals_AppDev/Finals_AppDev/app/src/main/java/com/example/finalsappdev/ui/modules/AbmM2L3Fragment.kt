package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM2L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Business and Marketing"
        binding.lessontextView.text = "Lesson 3: Marketing Strategies"
        binding.readingContent.text = "Marketing strategies help businesses promote their products and attract customers effectively."

        val lessons = listOf(
            "Digital marketing uses online platforms like social media and websites for promotion.",
            "Traditional marketing includes TV ads, newspapers, and billboards.",
            "Target audience analysis helps businesses focus on the right customers.",
            "Branding creates a unique identity for a business in the market.",
            "Customer engagement increases loyalty and sales through interaction."
        )

        val heading = listOf(
            "Digital Marketing: Online Promotion",
            "Traditional Marketing: Old but Effective",
            "Target Audience: Understanding Your Customers",
            "Branding: Creating a Strong Identity",
            "Customer Engagement: Building Relationships"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
