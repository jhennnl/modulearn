package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM2L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Technology"
        binding.lessontextView.text = "Lesson 2: Programming Fundamentals"
        binding.readingContent.text = "Programming is the foundation of modern technology, enabling us to develop software applications, websites, and systems that power businesses, entertainment, and daily life."

        val heading = listOf(
            "What is a Programming Language?",
            "Examples of High-Level Programming Languages",
            "Purpose of Variables in Programming",
            "Statement Termination in Java",
            "Understanding Program Output",
            "Purpose of Loops in Programming",
            "What is an IDE?",
            "Difference Between For and While Loops",
            "Purpose of Debugging",
            "What is an Algorithm?"
        )

        val lessons = listOf(
            "A programming language is a formal language used to communicate instructions to a computer. Unlike natural languages, which humans use for everyday communication, programming languages have strict syntax and semantics that define how instructions should be written. These languages allow developers to create software applications by giving step-by-step commands that a computer can interpret and execute. Examples of programming languages include Python, Java, and C++.",
            "High-level programming languages are designed to be more readable and understandable for humans compared to low-level languages like assembly or machine code. These languages abstract complex hardware operations, making programming more efficient and accessible. Examples of high-level programming languages include Python, Java, and C++, which are widely used for application development, web development, and artificial intelligence.",
            "In programming, variables are used to store data that can change during the execution of a program. They act as placeholders for values that a program may need to manipulate, such as user input, calculations, or temporary storage. Variables enhance flexibility in programming by allowing developers to work with dynamic data rather than fixed values. In Java, for instance, a variable can be declared using data types like int, double, or String.",
            "In Java, each statement typically ends with a semicolon (;). This symbol helps the compiler understand where one statement ends and the next begins, ensuring proper execution of the code. Without a semicolon, Java may produce a syntax error, preventing the program from running correctly. Understanding syntax rules like statement termination is essential for writing correct and efficient code.",
            "When a Java program executes a statement like System.out.println(\"Hello World\");, it prints the text \"Hello World\" to the console. This demonstrates how output is generated in Java using the println function. If the syntax is correct, the expected result is displayed; otherwise, errors may occur, which need to be debugged before execution.",
            "Loops are used in programming to execute a block of code repeatedly based on a given condition. This helps automate repetitive tasks and improves efficiency. The most common types of loops are for, while, and do-while loops. Loops are essential for tasks like iterating over data structures, processing user input, and implementing game mechanics.",
            "An Integrated Development Environment (IDE) is a software application that provides developers with tools for writing, debugging, and compiling code. IDEs streamline the development process by integrating features like syntax highlighting, error checking, and version control. Popular IDEs include Visual Studio Code, Eclipse, and IntelliJ IDEA, which support multiple programming languages and frameworks.",
            "Both for and while loops are used for iteration, but they serve different purposes. A for loop is ideal when the number of iterations is known beforehand, as it includes initialization, condition checking, and increment/decrement in a single statement. In contrast, a while loop is better suited for scenarios where the number of iterations is uncertain and depends on a specific condition being met during execution.",
            "Debugging is the process of identifying and fixing errors in a program's code. Bugs can cause incorrect output, crashes, or unexpected behavior in software applications. Developers use debugging tools, print statements, and breakpoints to diagnose and resolve issues efficiently. Debugging is a crucial step in software development to ensure the reliability and accuracy of a program.",
            "An algorithm is a step-by-step procedure or set of instructions for solving a problem. It serves as the logic behind a program, guiding how data is processed and manipulated. Algorithms can range from simple arithmetic calculations to complex artificial intelligence models. Writing efficient algorithms is essential for optimizing software performance and resource usage."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M2L2_to_M2)
        }

        return binding.root
    }
}