package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM3L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Financial Management"
        binding.lessontextView.text = "Lesson 1: Financial Management Basics"
        binding.readingContent.text = "Financial management is the process of planning, organizing, controlling, and monitoring financial resources to achieve business objectives. "

        val lessons = listOf(
            "Budgeting is the process of creating a financial plan that outlines expected income and expenses over a specific period. It helps individuals and businesses allocate resources efficiently and avoid overspending. A well-structured budget ensures financial stability and prevents financial crises.",
            "Cash flow management involves monitoring the money coming in and going out of a business. A positive cash flow ensures that a company has enough liquidity to meet its obligations, such as paying suppliers, salaries, and operating expenses. Poor cash flow management can lead to financial difficulties, even if a business is profitable.",
            "Investment planning helps businesses decide where to allocate funds for maximum returns. Companies invest in assets, stocks, bonds, or expansion projects to grow their capital. Smart investment decisions consider factors such as risk, return, and market conditions.",
            "Debt management is crucial in controlling liabilities and avoiding excessive borrowing. Businesses take loans for expansion, but poor debt management can lead to financial distress. Keeping debt at a manageable level and ensuring timely repayments is essential for financial stability.",
            "Financial risk assessment identifies potential threats that could impact a business's financial health. Companies analyze risks such as market fluctuations, economic downturns, and credit defaults to create strategies that minimize financial losses."
        )

        val heading = listOf(
            "Budgeting: Planning for Financial Stability",
            "Cash Flow Management: Ensuring Liquidity",
            "Investment Planning: Growing Wealth",
            "Debt Management: Controlling Liabilities",
            "Financial Risk Assessment: Identifying Threats"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
