package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class StemQuiz1Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "What is the basic unit of life?" to listOf("Atom", "Molecule", "Cell", "Organism"),
        "What is the chemical symbol for water?" to listOf("O2", "H2O", "CO2", "NaCl"),
        "What layer of the Earth lies beneath the crust?" to listOf("Mantle", "Outer Core", "Inner Core", "Lithosphere"),
        "What force keeps planets in orbit around the Sun?" to listOf("Magnetism", "Friction", "Gravity", "Inertia"),
        "What type of energy is stored in food?" to listOf("Thermal", "Kinetic", "Chemical", "Nuclear"),
        "What is the function of red blood cells?" to listOf("Fight infection", "Carry oxygen", "Clotting", "Produce hormones"),
        "What is the powerhouse of the cell?" to listOf("Nucleus", "Ribosome", "Mitochondria", "Golgi apparatus"),
        "What type of rock is formed from cooled lava or magma?" to listOf("Igneous", "Sedimentary", "Metamorphic", "Basalt"),
        "What planet is known as the Red Planet?" to listOf("Venus", "Earth", "Mars", "Jupiter"),
        "What is Newton's First Law of Motion also called?" to listOf("Law of Acceleration", "Law of Action-Reaction", "Law of Inertia", "Law of Gravity")
    )

    private val correctAnswers = listOf(2, 1, 0, 2, 2, 1, 2, 0, 2, 2)
    private var currentQuestionIndex = 0

    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "STEM Quiz 1"
        binding.backStrand.text = "Module 1: Science"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }


        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()

        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedRadioButtonId = binding.radioGroup.checkedRadioButtonId
        val selectedAnswerIndex = when (selectedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }


    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.STEMQ1_to_Score, bundle)
    }


    private fun calculateScore(): Int {
        var score = 0

        for (i in userAnswers.indices) {
            if (userAnswers[i] != -1) {
                if (userAnswers[i] == correctAnswers[i]) {
                    score++
                }
            }
        }

        return score
    }



    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
