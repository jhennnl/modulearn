package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM2L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Technology"
        binding.lessontextView.text = "Lesson 3: Emerging Technologies"
        binding.readingContent.text = "Technology is constantly evolving, shaping the way people live, work, and interact with the world. These advancements improve efficiency, enhance convenience, and open new possibilities for industries like healthcare, education, and business. "

        val heading = listOf(
            "Artificial Intelligence (AI)",
            "Wearable Technology",
            "Internet of Things (IoT)",
            "3D Printing",
            "Blockchain Technology",
            "Virtual Reality (VR)",
            "Machine Learning",
            "Smart Devices",
            "Cloud Computing",
            "Augmented Reality (AR) vs. Virtual Reality (VR)"
        )

        val lessons = listOf(
            "Artificial Intelligence is designed to enable machines to perform tasks that usually require human intelligence. It can analyze data, recognize patterns, and make decisions based on the information it receives. AI is widely used in different industries, helping businesses and individuals automate processes and improve decision-making.",
            "Wearable technology consists of smart devices that people can wear to track health, assist with communication, or enhance daily activities. These devices connect to the internet and offer convenience by providing real-time updates and insights. They are commonly used in fitness, healthcare, and personal productivity.",
            "The Internet of Things refers to a network of smart devices that can communicate with each other. These devices collect and share data, allowing for automation and improved efficiency. IoT is used in smart homes, industries, and transportation, making everyday tasks more convenient and efficient.",
            "3D printing is a technology that creates objects by adding layers of material. It is widely used in manufacturing, healthcare, and design because it allows for the creation of complex structures quickly and efficiently. This technology reduces waste and enables customization in production.",
            "Blockchain is a secure digital system for recording transactions. It is decentralized, meaning no single authority controls it, making it more transparent and resistant to tampering. It is widely used in digital currencies, secure transactions, and data management.",
            "Virtual Reality creates immersive digital experiences that replace the real world. While it is commonly used in gaming, it also has applications in education, training, and entertainment. VR allows users to interact with computer-generated environments in a highly engaging way.",
            "Machine learning is a technology that allows computers to improve their performance by learning from data. Instead of relying on strict programming, it adapts over time, making it useful in many applications like recommendations, automation, and data analysis.",
            "Smart devices are electronic gadgets that can connect to the internet and be controlled remotely. These devices are designed to make tasks easier and more efficient by using automation and real-time data. They are commonly found in households, workplaces, and everyday life.",
            "Cloud computing allows users to store and access data and applications over the internet instead of on a personal computer. It reduces the need for physical storage and makes it easier to access information from anywhere. Cloud services are used in businesses, education, and personal applications.",
            "Both Augmented Reality (AR) and Virtual Reality (VR) enhance digital experiences. AR adds digital elements to the real world, while VR fully immerses users in a virtual environment. These technologies are used in entertainment, training, and interactive applications to improve learning and engagement."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }


        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M2L3_to_M2)
        }

        return binding.root
    }
}