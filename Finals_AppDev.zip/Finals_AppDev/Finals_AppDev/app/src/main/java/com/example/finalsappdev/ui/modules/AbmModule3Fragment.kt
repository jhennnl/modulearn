package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class AbmModule3Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "ABM Module"
        binding.title.text = "Module 3: Financial Literacy"

        imageList = arrayOf(
            R.drawable.finance_basics,
            R.drawable.budgetings,
            R.drawable.investment,
            R.drawable.taxes,
            R.drawable.financial_managements
        )

        titleList = arrayOf(
            "Lesson 1: Financial Basics",
            "Lesson 2: Budgeting & Saving",
            "Lesson 3: Investment Strategies",
            "Lesson 4: Understanding Taxes",
            "Lesson 5: Financial Management"
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                when (selectedItem.dataTitle) {
                    "Lesson 1: Financial Basics" -> findNavController().navigate(R.id.ABM_M3_to_L1)
                    "Lesson 2: Budgeting & Saving" -> findNavController().navigate(R.id.ABM_M3_to_L2)
                    "Lesson 3: Investment Strategies" -> findNavController().navigate(R.id.ABM_M3_to_L3)
                    "Lesson 4: Understanding Taxes" -> findNavController().navigate(R.id.ABM_M3_to_L4)
                    "Lesson 5: Financial Management" -> findNavController().navigate(R.id.ABM_M3_to_L5)
                }
            }
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }
}
