package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class AbmQuiz4Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "What is the primary function of management?" to listOf("Planning", "Marketing", "Selling", "Investing"),
        "Which leadership style involves full control with little input from employees?" to listOf("Democratic", "Autocratic", "Laissez-faire", "Transformational"),
        "What is a SWOT analysis used for?" to listOf("Evaluating financial statements", "Assessing business performance", "Identifying strengths, weaknesses, opportunities, and threats", "Developing marketing campaigns"),
        "Which of the following is an example of a tangible asset?" to listOf("Brand reputation", "Patent", "Equipment", "Employee skills"),
        "What does KPI stand for in business management?" to listOf("Key Performance Indicator", "Knowledge Process Integration", "Key Production Input", "Kinetic Profit Investment")
    )

    private val correctAnswers = listOf(0, 1, 2, 2, 0)
    private var currentQuestionIndex = 0
    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "ABM Quiz 4"
        binding.backStrand.text = "Module 4: Entreoreneurship"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()
        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedAnswerIndex = when (binding.radioGroup.checkedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }

    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.ABMQ4_to_Score, bundle)
    }

    private fun calculateScore(): Int {
        return userAnswers.count { it != -1 && it == correctAnswers[it] }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
