package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class StemModule4Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "STEM Module"
        binding.title.text = "Module 4: Mathematics"

        imageList = arrayOf(
            R.drawable.math1,
            R.drawable.math2,
            R.drawable.math3,
            R.drawable.math4
        )

        titleList = arrayOf(
            "Lesson 1: Algebra",
            "Lesson 2: Trigonometry",
            "Lesson 3: Geometry",
            "Lesson 4: Calculus"
        )


        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                if (selectedItem.dataTitle == "Lesson 1: Algebra") {
                    findNavController().navigate(R.id.stemM4_to_stemM4L1)
                }
                if (selectedItem.dataTitle == "Lesson 2: Trigonometry") {
                    findNavController().navigate(R.id.stemM4_to_stemM4L2)
                }
                if (selectedItem.dataTitle == "Lesson 3: Geometry") {
                    findNavController().navigate(R.id.stemM4_to_stemM4L3)
                }
                if (selectedItem.dataTitle == "Lesson 4: Calculus") {
                    findNavController().navigate(R.id.stemM4_to_stemM4L4)
                }
            }
        }


        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemModule4Fragment_to_stemModuleFragment)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }

}
