package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM1L5Fragments : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Arts and Culture"
        binding.lessontextView.text = "Lesson 5: The Role of Arts in Society"
        binding.readingContent.text = "Art serves as more than just a form of entertainment; it is a powerful medium for social change, education, and emotional expression."

        val heading = listOf(
            "Art as a Reflection of Society",
            "Art as a Means of Social Change",
            "Art and Mental Well-Being",
            "The Economic and Cultural Impact of Art",
            "The Future of Art in Society"
        )
        val lessons = listOf(
            "Paintings, literature, music, and film often depict societal issues, capturing moments of joy, struggle, revolution, and transformation. (e.g., Picasso’s Guernica as a response to war, protest songs during civil rights movements)",
            "Many artists use their platforms to advocate for justice, equality, and environmental awareness. Street art, documentaries, and spoken-word poetry highlight pressing global issues.",
            "Studies show that engaging with art—whether through music, painting, dance, or writing—can enhance mental health, reduce stress, and foster emotional healing.",
            "Art also plays a crucial role in the economy and cultural development of societies.\n" +
                    "\n" +
                    "Tourism & Economy: Museums, galleries, music festivals, and theaters generate income and provide employment.\n" +
                    "Example: The Louvre in Paris attracts millions of visitors annually, boosting the local economy.\n" +
                    "Cultural Diplomacy: Art fosters international connections and understanding among cultures.\n" +
                    "Example: Cultural exchange programs allow artists to share their work globally, promoting unity and cross-cultural appreciation.",
            "With the rise of digital technology, art continues to evolve in new and exciting ways.\n" +
                    "\n" +
                    "Digital Art & NFTs: Digital platforms and blockchain technology have transformed the way artists share and monetize their work.\n" +
                    "AI & Art: Artificial intelligence is being used to create new forms of music, paintings, and literature.\n" +
                    "Virtual & Augmented Reality: Museums and galleries are incorporating immersive experiences to engage audiences in new ways."
        )


        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
