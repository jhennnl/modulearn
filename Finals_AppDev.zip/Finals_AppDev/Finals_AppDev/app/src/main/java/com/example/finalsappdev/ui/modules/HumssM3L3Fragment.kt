package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM3L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Psychology and Media"
        binding.lessontextView.text = "Lesson 3: The Power of Persuasion"
        binding.readingContent.text = "Persuasion is a fundamental skill used in marketing, politics, and everyday interactions, relying on psychological techniques to influence thoughts, decisions, and actions."

        val heading = listOf(
            "The Art of Persuasion: An Introduction",
            "Psychological Persuasion Techniques",
            "Persuasion in Advertising & Marketing",
            "Political Persuasion and Rhetoric",
            "The Ethics of Persuasion",
            "Persuasion in Leadership and Negotiation",
            "Persuasion in Everyday Life"
        )

        val lessons = listOf(
            "Persuasion is used in everyday life—from marketing to politics. The three pillars are:\n" +
                    "\n" +
                    "Ethos (Credibility): People trust experts.\n" +
                    "Pathos (Emotion): Emotional appeals are powerful.\n" +
                    "Logos (Logic): Facts and reasoning persuade people.\n" +
                    "Understanding persuasion helps in communication, business, and leadership.",
            "People are influenced by certain psychological triggers:\n" +
                    "\n" +
                    "Social Proof: \"Everyone is doing it, so you should too.\"\n" +
                    "Scarcity: \"Limited time only!\"\n" +
                    "Reciprocity: \"If I do something for you, you’ll do something for me.\"\n" +
                    "These techniques are used in marketing, politics, and negotiations.",
            "Why do some brands dominate?\n" +
                    "\n" +
                    "Emotional Branding: Nike sells motivation, not just shoes.\n" +
                    "Celebrity Endorsements: People trust famous figures.\n" +
                    "Color Psychology: Red for excitement, blue for trust.\n" +
                    "These tactics influence consumer decisions daily.\n" +
                    "\n",
            "Politicians use persuasive language to gain support:\n" +
                    "\n" +
                    "Speech Techniques: Repetition, storytelling, strong delivery.\n" +
                    "Slogans & Symbols: \"Yes We Can,\" \"Make America Great Again.\"\n" +
                    "Fear & Hope: Politicians promise security or change.\n" +
                    "Understanding rhetoric helps voters make informed choices.",
            "Is it ethical to manipulate people’s emotions?\n" +
                    "\n" +
                    "Honest Persuasion: Using facts and reason.\n" +
                    "Deceptive Persuasion: Misleading or exploiting emotions.\n" +
                    "Persuasion can be a force for good or manipulation.",
            "Great leaders are great persuaders. They use:\n" +
                    "\n" +
                    "Confidence & Charisma: Making people believe in their vision.\n" +
                    "Compromise & Diplomacy: Negotiating for win-win outcomes.\n" +
                    "Mastering persuasion is essential in careers and relationships.\n" +
                    "\n",
            "From convincing parents to getting a job, persuasion is everywhere.\n" +
                    "\n" +
                    "Building Rapport: Connecting with people.\n" +
                    "The Power of \"Because\": Giving reasons increases compliance.\n" +
                    "Understanding persuasion improves communication skills."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}