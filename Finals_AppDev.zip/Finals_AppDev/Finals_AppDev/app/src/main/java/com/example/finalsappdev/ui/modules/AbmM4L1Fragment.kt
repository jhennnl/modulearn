package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM4L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Marketing Management"
        binding.lessontextView.text = "Lesson 1: Marketing and Consumer Behavior"
        binding.readingContent.text = "Marketing is the process of promoting, selling, and distributing a product or service to consumers."

        val lessons = listOf(
            "Marketing involves identifying customer needs and creating products or services that satisfy them. It includes market research, branding, advertising, and distribution strategies. A strong marketing plan ensures business success and customer satisfaction.",
            "The 4Ps of marketing—Product, Price, Place, and Promotion—form the foundation of marketing strategies. Businesses must balance these factors to maximize sales, build brand recognition, and create customer loyalty.",
            "Consumer behavior refers to how individuals or groups make purchasing decisions. Factors such as personal preferences, social influences, and economic conditions affect their choices. Understanding these behaviors helps businesses tailor their marketing strategies.",
            "Market segmentation divides a broad consumer market into smaller groups with similar characteristics. This allows businesses to target specific customers based on demographics, behavior, and interests, leading to more effective marketing efforts.",
            "A strong brand creates trust, recognition, and customer loyalty. Effective branding involves creating a unique identity, logo, and messaging that resonates with consumers and differentiates the business from competitors."
        )

        val heading = listOf(
            "What is Marketing? Understanding the Basics",
            "The 4Ps of Marketing: Key Strategies for Success",
            "Consumer Behavior: How Customers Make Buying Decisions",
            "Market Segmentation: Targeting the Right Audience",
            "Branding: Building a Strong Business Identity"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
