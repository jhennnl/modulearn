package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM2L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Technology"
        binding.lessontextView.text = "Lesson 1: Central Processing Unit"
        binding.readingContent.text = "Explores the key hardware components of a computer, including the CPU, RAM, motherboard, and storage devices, and their roles in processing and storing data."

        val heading = listOf(
            "CPU (Central Processing Unit)",
            "RAM (Random Access Memory)",
            "HTTP (Hypertext Transfer Protocol)",
            "Binary Code",
            "Motherboard",
            "Web Browsers",
            "Hardware vs. Software",
            "Binary Code Revisited",
            "Commonly Used Web Browsers",
            "Best Definition of Hardware and Software"
        )

        val lessons = listOf(
            "The CPU, or Central Processing Unit, is often referred to as the \"brain\" of the computer. It is responsible for executing instructions from programs, performing calculations, and managing data processing. Every action performed on a computer, from opening an application to browsing the internet, is processed by the CPU. It works in conjunction with other hardware components to ensure smooth operation.",
            "RAM, or Random Access Memory, is a form of temporary storage that holds data and instructions currently being used by the CPU. Unlike a hard drive or SSD, RAM does not store data permanently; instead, it provides fast, temporary access to information while a computer is running. This allows for efficient multitasking and quick processing of applications. When the computer is turned off, the data in RAM is erased.",
            "HTTP, or Hypertext Transfer Protocol, is the foundation of communication on the World Wide Web. It allows web browsers and servers to exchange information, enabling users to access websites and retrieve data. When a user types a web address into a browser, HTTP facilitates the request for the webpage and ensures that the necessary data is transmitted between the browser and the server.",
            "Binary code is the fundamental language of computers, consisting of only two digits: 0 and 1. Every piece of digital information, from text and images to software and commands, is represented in binary form. These binary numbers are processed by the computer’s hardware to execute various functions. Since computers operate on electrical signals, binary code simplifies data processing through on (1) and off (0) states.",
            "The motherboard is the main circuit board of a computer, serving as the central hub that connects all components, including the CPU, RAM, hard drive, and other peripherals. It allows communication between different parts of the system, ensuring that data is transferred efficiently. The motherboard also contains slots for expansion cards, ports for external devices, and firmware that helps boot the computer.",
            "A web browser is a software application used to access and navigate the internet. Some commonly used web browsers include Google Chrome, Mozilla Firefox, Microsoft Edge, and Safari. These browsers enable users to visit websites, view multimedia content, and interact with online services. They interpret HTML, CSS, and JavaScript to display web pages correctly.",
            "Hardware refers to the physical components of a computer, such as the CPU, RAM, hard drive, and motherboard. It is the tangible part of the system that users can touch and see. On the other hand, software consists of programs and instructions that run on the hardware, including operating systems, applications, and utilities. Software allows users to perform tasks such as writing documents, browsing the web, and playing games.",
            "As mentioned earlier, binary code is composed of 0s and 1s, representing data and instructions for the computer. This system allows for efficient processing and storage of information. Every letter, number, and symbol on a computer is translated into binary code before it is processed.",
            "Among the many web browsers available, Google Chrome is one of the most widely used due to its speed, security, and compatibility with various devices. Other popular browsers include Microsoft Edge, Mozilla Firefox, and Apple Safari. These browsers provide essential tools for accessing online content and services.",
            "The best way to differentiate hardware and software is by understanding their roles in a computer system. Hardware includes all physical components, while software consists of the programs that operate on the hardware. Without software, hardware would be non-functional, and without hardware, software would have no platform to run on. Both are essential for a computer to function properly."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M2L1_to_M2)
        }

        return binding.root
    }
}