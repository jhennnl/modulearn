package com.example.finalsappdev.ui.starting

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentGetstartedBinding

class GetStartedFragment : Fragment() {
    private lateinit var binding: FragmentGetstartedBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentGetstartedBinding.inflate(inflater, container, false)
        requireActivity().findViewById<View>(R.id.nav_view)?.visibility = View.GONE

        binding.getstartedBtn.setOnClickListener {
            findNavController().navigate(R.id.getStarted_to_login)
        }

        return binding.root
    }
}
