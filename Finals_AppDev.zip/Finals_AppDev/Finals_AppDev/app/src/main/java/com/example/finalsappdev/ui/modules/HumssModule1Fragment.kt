package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class HumssModule1Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "Humss Module"
        binding.title.text = "Module 1: Arts and Culture"

        imageList = arrayOf(
            R.drawable.literature,
            R.drawable.painting,
            R.drawable.temple,
            R.drawable.writing,
            R.drawable.people
        )

        titleList = arrayOf(
            "Lesson 1: Literary Forms & Genre",
            "Lesson 2: Art Movements & Styles",
            "Lesson 3: Cultural Identity & Heritage",
            "Lesson 4: Creative Writing & Analysis",
            "Lesson 5: The Role of Arts in Society"
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                if (selectedItem.dataTitle == "Lesson 1: Literary Forms & Genre") {
                    findNavController().navigate(R.id.HUMSS_M1_to_L1)
                }
                if (selectedItem.dataTitle == "Lesson 2: Art Movements & Styles") {
                    findNavController().navigate(R.id.HUMSS_M1_to_L2)
                }
                if (selectedItem.dataTitle == "Lesson 3: Cultural Identity & Heritage") {
                    findNavController().navigate(R.id.HUMSS_M1_to_L3)
                }
                if (selectedItem.dataTitle == "Lesson 4: Creative Writing & Analysis") {
                    findNavController().navigate(R.id.HUMSS_M1_to_L4)
                }
                if (selectedItem.dataTitle == "Lesson 5: The Role of Arts in Society") {
                    findNavController().navigate(R.id.HUMSS_M1_to_L5)
                }
            }
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }

}
