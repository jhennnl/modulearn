package com.example.finalsappdev

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.finalsappdev.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_activity_main)

        navView.visibility = View.GONE

        navView.setupWithNavController(navController)

        navController.addOnDestinationChangedListener { _, destination, _ ->
            val hideFragments = setOf(R.id.getstartedBtn, R.id.loginPage, R.id.signUpPage)

            if (destination.id in hideFragments) {
                navView.visibility = View.GONE
            } else {
                navView.visibility = View.VISIBLE
            }

            val moduleFragments = setOf(R.id.navigation_modules, R.id.stemModuleFragment, R.id.stemModule1Fragment, R.id.btnstemQ1Fragment, R.id.btnstemQ2Fragment, R.id.btnstemQ3Fragment, R.id.btnstemQ4Fragment, R.id.btnscoreFragment, R.id.stemlesson1fragment, R.id.stemModule2Fragment, R.id.stemModule3Fragment, R.id.stemModule4Fragment, R.id.stemlesson2fragment, R.id.stemlesson3fragment, R.id.stemlesson4fragment, R.id.stemlesson5fragment, R.id.stemM2L1, R.id.stemM2L2, R.id.stemM2L3, R.id.stemM3L1, R.id.stemM3L2, R.id.stemM3L3, R.id.stemM4L1, R.id.stemM4L2, R.id.stemM4L3, R.id.stemM4L4,
                R.id.humssModuleFragment, R.id.btnhumssQ1Fragment, R.id.btnhumssQ2Fragment, R.id.btnhumssQ3Fragment, R.id.btnhumssscoreFragment1, R.id.btnhumssscoreFragment2, R.id.btnhumssscoreFragment3, R.id.humssModule1Fragment, R.id.humssM1L1, R.id.humssM1L2, R.id.humssM1L3, R.id.humssM1L4, R.id.humssM1L5, R.id.humssModule2Fragment, R.id.humssM2L1, R.id.humssM2L2, R.id.humssM2L3, R.id.humssModule3Fragment, R.id.humssM3L1, R.id.humssM3L2, R.id.humssM3L3,
                R.id.abmModuleFragment, R.id.btnabmQ1Fragment, R.id.btnabmQ2Fragment, R.id.btnabmQ3Fragment, R.id.btnabmQ4Fragment, R.id.btnabmscoreFragment1, R.id.btnabmscoreFragment2, R.id.btnabmscoreFragment3, R.id.btnabmscoreFragment4, R.id.abmModule1Fragment, R.id.abmM1L1, R.id.abmM1L2, R.id.abmM1L3, R.id.abmM1L4, R.id.abmModule2Fragment, R.id.abmM2L1, R.id.abmM2L2, R.id.abmM2L3, R.id.abmM2L4, R.id.abmModule3Fragment, R.id.abmM3L1, R.id.abmM3L2, R.id.abmM3L3, R.id.abmM3L4, R.id.abmM3L5, R.id.abmModule4Fragment, R.id.abmM4L1, R.id.abmM4L2, R.id.abmM4L3, R.id.abmM4L4, R.id.abmM4L5
            )
            if (destination.id in moduleFragments) {
                navView.menu.findItem(R.id.navigation_modules).isChecked = true
            }

            val aboutdev = R.id.developerFragment
            if (destination.id == aboutdev) {
                navView.menu.findItem(R.id.navigation_settings).isChecked = true
            }
        }
    }
}
