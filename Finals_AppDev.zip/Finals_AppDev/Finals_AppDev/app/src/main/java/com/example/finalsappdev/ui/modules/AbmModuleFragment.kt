package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentEnrolledBinding

class AbmModuleFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var dataList: ArrayList<dataClass2>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>
    private lateinit var quizList: Array<Int>
    private lateinit var contextList: Array<String>

    private var _binding: FragmentEnrolledBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEnrolledBinding.inflate(inflater, container, false)

        binding.moduleTitle.text = "ABM Modules"

        imageList = arrayOf(
            R.drawable.business_basics,
            R.drawable.marketing,
            R.drawable.accounting,
            R.drawable.economics
        )

        titleList = arrayOf(
            "Module 1: Business Fundamentals",
            "Module 2: Marketing Strategies",
            "Module 3: Financial Management",
            "Module 4: Entrepreneurship"
            )

        quizList = arrayOf(
            R.id.btnabmQ1Fragment,
            R.id.btnabmQ2Fragment,
            R.id.btnabmQ3Fragment,
            R.id.btnabmQ4Fragment
        )

        contextList = arrayOf(
            "4 Lessons",
            "4 Lessons",
            "5 Lessons",
            "4 Lessons"
        )

        recyclerView = binding.recyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.setHasFixedSize(true)

        dataList = arrayListOf()
        getData()

        binding.changeStrandText.setOnClickListener {
            findNavController().navigate(R.id.ABM_to_ChangeStrand)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData() {
        for (i in imageList.indices) {
            val data = dataClass2(imageList[i], titleList[i], quizList[i], contextList[i])
            dataList.add(data)
        }

        recyclerView.adapter = adapterClass2(dataList) { selectedItem, isQuizButton ->
            val navController = findNavController()
            if (isQuizButton) {
                navController.navigate(selectedItem.quizFragment)
            } else {
                when (selectedItem.dataTitle) {
                    "Module 1: Business Fundamentals" -> navController.navigate(R.id.abm_ABM_M1)
                    "Module 2: Marketing Strategies" -> navController.navigate(R.id.abm_ABM_M2)
                    "Module 3: Financial Management" -> navController.navigate(R.id.abm_ABM_M3)
                    "Module 4: Entrepreneurship" -> navController.navigate(R.id.abm_ABM_M4)
                }
            }
        }
    }
}
