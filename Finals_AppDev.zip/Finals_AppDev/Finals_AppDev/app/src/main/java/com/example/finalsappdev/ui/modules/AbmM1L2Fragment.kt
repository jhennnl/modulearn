package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM1L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Business Fundamentals"
        binding.lessontextView.text = "Lesson 2: Principles of Management"
        binding.readingContent.text = "Management is the process of planning, organizing, leading, and controlling resources to achieve organizational goals."

        val lessons = listOf(
            "Planning involves setting objectives and determining the best course of action to achieve them.",
            "Organizing is the process of arranging resources and tasks to implement a plan efficiently.",
            "Leading involves motivating and directing employees to meet business objectives.",
            "Controlling ensures that actual performance meets expected goals through monitoring and evaluation.",
            "Decision-making is a critical function in management that involves choosing the best alternative from available options."
        )

        val heading = listOf(
            "Planning: Setting Goals and Strategies",
            "Organizing: Structuring the Business",
            "Leading: Guiding the Team",
            "Controlling: Ensuring Performance",
            "Decision-Making: Choosing the Best Path"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
