package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM1L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Science"
        binding.lessontextView.text = "Lesson 2: Physics"
        binding.readingContent.text = "Physics is the scientific study of matter, energy, and their interactions, governing everything from the smallest subatomic particles to the vast galaxies in the universe."

        val heading = listOf(
            "Electricity and Measurements",
            "Light and Optics",
            "Energy and Work",
            "Gravity and Acceleration",
            "Forces and Newton’s Laws",
            "Speed and Motion"
        )

        val lessons = listOf(
            "In electrical circuits, an ammeter is used to measure electric current. Other measuring devices include voltmeters for voltage and ohmmeters for resistance. Understanding electricity is crucial in technology, engineering, and daily applications such as power generation and electronics.",
            "Light behaves in different ways when it interacts with surfaces and media. A convex mirror curves outward and is commonly used in vehicles for wide-angle viewing. When light bends while passing through different media, the phenomenon is called refraction. This principle is applied in lenses, eyeglasses, and optical instruments.",
            "Energy exists in different forms. A moving object possesses kinetic energy, while a stationary object with potential to move has potential energy. Work is done when a force is applied to an object, causing displacement, and it is measured in Joules (J).",
            "Gravity is the force that pulls objects toward the Earth, affecting everything from falling objects to planetary motion. The rate of change of velocity is called acceleration, which is crucial in understanding motion in physics, including free fall and vehicle dynamics.",
            "A force is a push or pull that can cause an object to move, stop, or change direction. The SI unit of force is the Newton (N). Newton’s First Law of Motion, also known as the Law of Inertia, states that an object will remain at rest or in uniform motion unless acted upon by an external force. This principle explains why seat belts are essential for safety in vehicles.",
            "Speed is a measure of how quickly an object moves over a distance. It is calculated using the formula:\n" +
                    "\n" +
                    "Speed = Distance ÷ Time\n" +
                    "\n" +
                    "This fundamental concept is crucial in fields such as transportation, engineering, and sports."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemlesson1Fragment_to_stemModule1Fragment)
        }

        return binding.root
    }
}
