package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM2L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Business Planning"
        binding.lessontextView.text = "Lesson 2: Business Models"
        binding.readingContent.text = "A business model describes how a company creates, delivers, and captures value."

        val lessons = listOf(
            "The subscription model generates revenue through recurring payments.",
            "The freemium model offers basic services for free and charges for premium features.",
            "The direct sales model involves selling products directly to consumers.",
            "The franchise model allows businesses to expand by licensing their brand.",
            "The e-commerce model involves selling goods and services online."
        )

        val heading = listOf(
            "Subscription Model: Recurring Revenue",
            "Freemium Model: Free and Paid Services",
            "Direct Sales Model: Selling to Customers",
            "Franchise Model: Expanding a Business",
            "E-Commerce Model: Online Selling"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
