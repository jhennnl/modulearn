package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class StemQuiz2Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "What does CPU stand for?" to listOf("Central Processing Unit", "Computer Processing Unit", "Core Processing Unit", "Central Power Unit"),
        "Which company developed the Windows operating system?" to listOf("Apple", "Microsoft", "Google", "IBM"),
        "What does HTML stand for?" to listOf("HyperText Markup Language", "HighText Machine Language", "Hyperlink and Text Markup Language", "Home Tool Markup Language"),
        "Which wireless technology is commonly used for short-distance communication between devices?" to listOf("Wi-Fi", "Bluetooth", "NFC", "Infrared"),
        "What is the primary function of RAM in a computer?" to listOf("Store long-term files", "Process graphics", "Store temporary data", "Manage power supply"),
        "Which of the following is an open-source operating system?" to listOf("Windows", "macOS", "Linux", "iOS"),
        "What programming language is primarily used for Android development?" to listOf("Swift", "Java", "C++", "Kotlin"),
        "What does AI stand for in technology?" to listOf("Automated Interface", "Artificial Intelligence", "Advanced Integration", "Applied Information"),
        "Which social media platform is owned by Meta?" to listOf("Twitter", "LinkedIn", "Facebook", "Snapchat"),
        "What is the term for malicious software designed to harm or exploit computers?" to listOf("Firewall", "Malware", "Antivirus", "Encryption")
    )

    private val correctAnswers = listOf(0, 1, 0, 1, 2, 2, 3, 1, 2, 1)
    private var currentQuestionIndex = 0


    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "STEM Quiz 2"
        binding.backStrand.text = "Module 2: Technology"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"


        binding.radioGroup.clearCheck()


        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedRadioButtonId = binding.radioGroup.checkedRadioButtonId
        val selectedAnswerIndex = when (selectedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }


    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.STEMQ2_to_Score, bundle)
    }


    private fun calculateScore(): Int {
        var score = 0

        for (i in userAnswers.indices) {
            if (userAnswers[i] != -1) {
                if (userAnswers[i] == correctAnswers[i]) {
                    score++
                }
            }
        }

        return score
    }



    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
