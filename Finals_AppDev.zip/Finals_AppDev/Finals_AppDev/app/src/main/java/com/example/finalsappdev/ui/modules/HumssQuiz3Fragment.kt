package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class HumssQuiz3Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "Human behavior is influenced by:" to listOf("Genetics", "Environment", "Culture", "All of the above"),
        "What psychological perspective focuses on observable behavior?" to listOf("Psychoanalytic", "Cognitive", "Behaviorist", "Humanistic"),
        "Who developed the theory of cognitive development?" to listOf("Jean Piaget", "Abraham Maslow", "Ivan Pavlov", "Carl Jung"),
        "What is emotional intelligence?" to listOf("The ability to solve complex math problems", "The ability to recognize and manage emotions in oneself and others", "The ability to memorize large amounts of information", "The ability to multitask effectively"),
        "What is an example of social learning?" to listOf("A child learning to walk by trial and error", "A student studying in a library alone", "A teenager copying fashion trends from influencers", "A dog learning to sit for a treat"),
        "Fake news is often created to:" to listOf("Entertain people", "Misinform or manipulate public opinion", "Promote critical thinking", "Provide purely factual information"),
        "What is a major ethical concern in journalism?" to listOf("Ensuring accuracy and fairness in reporting", "Writing only positive stories", "Avoiding serious news topics", "Making news as dramatic as possible"),
        "What is the ethos appeal in persuasion?" to listOf("Emotional appeal", "Logical reasoning", "Ethical credibility of the speaker", "Use of threats"),
        "What is an example of logos (logical appeal) in persuasion?" to listOf("Using emotional stories to convince someone", "Presenting statistics and facts", "Using a celebrity endorsement", "Creating a sense of fear"),
        "Scenario: A government censors all opposition and controls the media. This is an example of:" to listOf("Democracy", "Authoritarianism", "Capitalism", "Utilitarianism")
    )

    private val correctAnswers = listOf(3, 2, 0, 1, 2, 1, 0, 2, 1, 1)
    private var currentQuestionIndex = 0
    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "HUMSS Quiz 3"
        binding.backStrand.text = "Module 3: Psychology and Media"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()
        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedAnswerIndex = when (binding.radioGroup.checkedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }

    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.HUMSSQ3_to_Score, bundle)
    }

    private fun calculateScore(): Int {
        return userAnswers.count { it != -1 && it == correctAnswers[it] }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}