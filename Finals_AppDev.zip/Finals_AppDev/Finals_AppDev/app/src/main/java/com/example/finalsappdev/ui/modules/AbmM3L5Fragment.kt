package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM3L5Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Financial Management"
        binding.lessontextView.text = "Lesson 5: Budgeting and Financial Planning"
        binding.readingContent.text = "Budgeting and financial planning are essential tools for businesses to manage money effectively."

        val lessons = listOf(
            "A business budget is a financial plan that outlines expected income and expenses over a specific period. It helps businesses control spending, allocate resources efficiently, and ensure financial stability.",
            "Revenue forecasting involves estimating future sales and income based on past trends and market conditions. Accurate forecasts help businesses plan for growth, set achievable goals, and make informed financial decisions.",
            "Expense tracking ensures that businesses monitor where their money is being spent. This helps identify unnecessary costs, prevent overspending, and allocate funds effectively for essential operations.",
            "Emergency funds are savings set aside for unexpected expenses such as economic downturns, equipment failure, or unforeseen market challenges. Maintaining an emergency fund ensures business continuity during financial difficulties.",
            "Long-term financial planning involves setting financial goals, investment strategies, and expansion plans for future business growth. This includes capital investment, risk management, and strategic planning to ensure long-term sustainability."
        )

        val heading = listOf(
            "Business Budget: Planning Income and Expenses",
            "Revenue Forecasting: Predicting Business Growth",
            "Expense Tracking: Managing Business Costs",
            "Emergency Funds: Preparing for Financial Risks",
            "Long-Term Financial Planning: Ensuring Business Sustainability"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
