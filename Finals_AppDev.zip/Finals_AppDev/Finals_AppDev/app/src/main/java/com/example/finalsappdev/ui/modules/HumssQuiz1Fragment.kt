package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class HumssQuiz1Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "Which of the following is NOT a literary genre?" to listOf("Poetry", "Fiction", "Sculpture", "Drama"),
        "What is the main characteristic of a novel?" to listOf("It is written in verse", "It is a long narrative work", "It follows a strict rhyme scheme", "It consists only of dialogue"),
        "Which art movement is characterized by the use of light and color to capture a moment?" to listOf("Cubism", "Surrealism", "Impressionism", "Realism"),
        "Pablo Picasso was a pioneer of which art movement?" to listOf("Dadaism", "Expressionism", "Cubism", "Baroque"),
        "Cultural heritage includes which of the following?" to listOf("Traditional dances", "Ancient architecture", "Folk tales", "All of the above"),
        "Which term describes the blending of different cultural elements into a new, unique culture?" to listOf("Ethnocentrism", "Assimilation", "Cultural Syncretism", "Cultural Isolation"),
        "In creative writing, which element establishes the time and place of a story?" to listOf("Theme", "Plot", "Setting", "Characterization"),
        "What is the purpose of literary analysis?" to listOf("To summarize a story", "To explore deeper meanings and themes in literature", "To memorize characters' names", "To rewrite the story with a different ending"),
        "Which of the following is NOT a function of the arts in society?" to listOf("Expressing cultural values", "Promoting political messages", "Serving as a form of therapy", "Replacing scientific research"),
        "How do the arts contribute to social change?" to listOf("By reinforcing traditional norms only", "By providing a platform for marginalized voices", "By eliminating all cultural differences", "By avoiding controversial topics")
    )

    private val correctAnswers = listOf(2, 1, 2, 2, 3, 2, 2, 1, 3, 1)
    private var currentQuestionIndex = 0
    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "HUMSS Quiz 1"
        binding.backStrand.text = "Module 1: Arts and Culture"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()
        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedRadioButtonId = binding.radioGroup.checkedRadioButtonId
        val selectedAnswerIndex = when (selectedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }


    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.HUMSSQ1_to_Score, bundle)
    }

    private fun calculateScore(): Int {
        var score = 0

        for (i in userAnswers.indices) {
            if (userAnswers[i] != -1) {
                if (userAnswers[i] == correctAnswers[i]) {
                    score++
                }
            }
        }

        return score
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}