package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM1L5Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Science"
        binding.lessontextView.text = "Lesson 5: Space Science"
        binding.readingContent.text = "Space Science is the study of celestial objects, space exploration, and the vast universe beyond Earth. It helps us understand planets, stars, galaxies, and cosmic phenomena that shape our universe."

        val heading = listOf(
            "The Solar System",
            "Stars and Galaxies",
            "The Role of Gravity",
            "Eclipses and Space Events",
            "Asteroids, Comets, and Space Objects",
            "Space Exploration"
        )

        val lessons = listOf(
            "The Solar System consists of the Sun, eight planets, moons, asteroids, and comets. The closest planet to the Sun is Mercury, followed by Venus, Earth, and Mars. Mars, known as the Red Planet, gets its color from iron oxide (rust) on its surface. The largest planet is Jupiter, famous for its Great Red Spot, a massive storm.",
            "A star is a large ball of hot gas that emits light and heat due to nuclear fusion. Our Sun is an example of a star. Stars are grouped into massive collections called galaxies. The Milky Way Galaxy is where our Solar System is located. Other galaxies, like the Andromeda Galaxy, are millions of light-years away.",
            "Gravity is the force that governs the movement of celestial bodies. It keeps planets in orbit around the Sun and holds moons in orbit around planets. Earth's only natural satellite, the Moon, plays a role in ocean tides due to its gravitational pull.",
            "When the Moon passes between the Earth and the Sun, it creates a solar eclipse, temporarily blocking sunlight. A lunar eclipse occurs when the Earth casts a shadow on the Moon. These events offer stunning views and valuable scientific insights.",
            "Asteroids are rocky objects that orbit the Sun but are too small to be classified as planets. They are mostly found in the asteroid belt between Mars and Jupiter. Comets are icy bodies that release gas and dust, forming a glowing tail when they approach the Sun.",
            "Humans have explored space through telescopes, satellites, and spacecraft. In 1969, the Apollo 11 mission carried astronauts to the Moon, marking a historic milestone. Today, space agencies like NASA and SpaceX continue to push the boundaries of space exploration, with future plans for Mars missions and beyond."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }


        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.action_stemlesson5Fragment_to_stemModule1Fragment)
        }

        return binding.root
    }
}