package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM4L4Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Mathematics"
        binding.lessontextView.text = "Lesson 4: Calculus"
        binding.readingContent.text = "Calculus is the study of change, focusing on differentiation (derivatives) and integration (antiderivatives). These concepts help analyze motion, rates, and accumulation in various fields."

        val heading = listOf(
            "Understanding Derivatives",
            "The Role of Integration",
            "Finding the Slope of a Tangent Line",
            "Derivatives of Linear Functions",
            "Derivatives of Trigonometric Functions",
            "Integration of Power Functions",
            "Exponential Functions and Their Derivatives",
            "Logarithmic Functions in Calculus"
        )

        val lessons = listOf(
            "A derivative measures how a function changes at any point. It helps determine the slope of a curve and is used in motion analysis, optimization, and predicting trends.",
            "Integration is the reverse process of differentiation. It helps find areas under curves, total distances traveled, and accumulated quantities over time.",
            "The slope of a tangent line to a curve represents how steep the curve is at a specific point. It is determined using derivatives and is useful in analyzing movement and growth rates.",
            "For simple linear functions, the derivative is a constant value. This means their rate of change remains the same everywhere.",
            "Trigonometric functions, like sine and cosine, have specific rules for differentiation. These derivatives are useful in wave motion, sound analysis, and engineering applications.",
            "When integrating functions, the result represents the accumulated value of a changing quantity. It is widely used in physics to calculate displacement, work, and energy.",
            "Exponential functions grow rapidly, and their derivatives maintain a unique property where they remain proportional to the original function. This is important in population modeling and financial calculations.",
            "Logarithms simplify complex calculations, and their derivatives help in solving equations related to growth rates, signal processing, and scientific measurements."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M4L1_to_M4)
        }

        return binding.root
    }
}