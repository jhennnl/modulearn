package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM4L4Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Marketing Management"
        binding.lessontextView.text = "Lesson 4: Pricing Strategies"
        binding.readingContent.text = "Pricing strategies play a crucial role in marketing by influencing consumer behavior, perception of value, and purchasing decisions."

        val lessons = listOf(
            "Cost-based pricing involves setting prices based on production costs plus a desired profit margin. This ensures that businesses cover expenses while making a reasonable profit.",
            "Value-based pricing focuses on the perceived value of a product to the customer rather than just production costs. This strategy allows businesses to charge higher prices for products with strong branding and unique benefits.",
            "Competitive pricing involves setting prices based on competitors’ pricing strategies. Businesses may price their products lower, higher, or match competitors depending on their market positioning.",
            "Psychological pricing techniques, such as charm pricing (e.g., $9.99 instead of $10) and bundling products together, influence customer perceptions and encourage purchases.",
            "Discounts and promotions create urgency and attract customers. Limited-time offers, seasonal sales, and loyalty programs encourage repeat purchases and increase brand engagement."
        )

        val heading = listOf(
            "Cost-Based Pricing: Covering Expenses and Profits",
            "Value-Based Pricing: Charging for Perceived Value",
            "Competitive Pricing: Staying Ahead in the Market",
            "Psychological Pricing: Influencing Consumer Behavior",
            "Discounts and Promotions: Encouraging Customer Loyalty"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
