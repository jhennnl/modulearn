package com.example.finalsappdev.ui.starting

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R

import com.example.finalsappdev.databinding.FragmentSignupBinding

class SignUpFragment : Fragment() {
    private lateinit var binding: FragmentSignupBinding
    private lateinit var dbHelper: Database

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSignupBinding.inflate(inflater, container, false)
        dbHelper = Database(requireContext())

        requireActivity().findViewById<View>(R.id.nav_view)?.visibility = View.GONE

        binding.loginBtn.setOnClickListener {
            findNavController().navigate(R.id.signUp_to_login)
        }

        binding.confirmBtn.setOnClickListener {
            registerUser()
        }

        return binding.root
    }

    private fun registerUser() {
        val firstName = binding.editText2.text.toString().trim()
        val lastName = binding.editText1.text.toString().trim()
        val username = binding.editText3.text.toString().trim()
        val password = binding.editText4.text.toString().trim()

        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()) {
            Toast.makeText(requireContext(), "All fields are required", Toast.LENGTH_SHORT).show()
            return
        }

        val success = dbHelper.insertUser(firstName, lastName, username, password)
        if (success) {
            Toast.makeText(requireContext(), "Sign up successful!", Toast.LENGTH_SHORT).show()
            findNavController().navigate(R.id.signUp_to_login)
        } else {
            Toast.makeText(requireContext(), "Username already exists", Toast.LENGTH_SHORT).show()
        }
    }
}
