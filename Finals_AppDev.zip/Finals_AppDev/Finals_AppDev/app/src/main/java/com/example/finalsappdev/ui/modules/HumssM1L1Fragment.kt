package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM1L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Arts and Culture"
        binding.lessontextView.text = "Lesson 1: Literary Forms & Genre"
        binding.readingContent.text = "Literature captures human emotions, experiences, and ideas through different forms and genres, each serving a unique purpose in storytelling and expression."

        val heading = listOf(
            "Introduction",
            "4 Major Genres in Literature: ",
            "Poetry",
            "Fiction",
            "Drama",
            "Non-Fiction",
            "Oral Literature and Folklore"
        )

        val lessons = listOf(
            "Literature is a reflection of human experiences, emotions, and ideas. It allows individuals to understand different perspectives, historical contexts, and cultural values.",
            "1. Poetry \n 2. Fiction \n 3. Drama \n 4. Non-Fiction",
            "Expresses emotions and ideas through rhythmic, figurative, and often symbolic language. It uses devices like metaphor, simile, and imagery to convey meaning. (e.g., Shakespeare’s sonnets, Pablo Neruda’s love poems)",
            "Includes short stories and novels that tell imaginative or realistic narratives, allowing readers to explore different worlds, characters, and themes. (e.g., Gabriel García Márquez’s One Hundred Years of Solitude, George Orwell’s 1984)",
            "Written for performance, featuring dialogue and stage directions that bring stories to life on stage or screen. It often explores conflict, relationships, and moral dilemmas. (e.g., Sophocles’ Oedipus Rex, Shakespeare’s Hamlet)",
            "Factual writing that presents real events, people, and ideas, ranging from autobiographies to essays, journals, and historical accounts. (e.g., Malala Yousafzai’s I Am Malala, Michelle Obama’s Becoming)",
            "Myths, legends, fables, and epics from various cultures."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson

            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
