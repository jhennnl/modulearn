package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM2L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Philosophy and Society"
        binding.lessontextView.text = "Lesson 2: Ethics and Moral Dilemmas"
        binding.readingContent.text = "Ethics is the study of moral principles and how they guide human behavior."

        val heading = listOf(
            "Introduction to Ethics",
            "Moral Relativism vs. Moral Absolutism",
            "The Trolley Problem and Utilitarianism",
            "Ethical Issues in AI and Technology",
            "Medical Ethics: Euthanasia and Organ Donation",
            "Environmental Ethics: Sustainability and Animal Rights",
            "Business Ethics and Corporate Responsibility",
            "Ethics in War and Peace"
        )

        val lessons = listOf(
            "Ethics is the philosophical study of morality—what is right or wrong, good or bad. Every society has moral rules, but where do they come from? Are they absolute, or do they change with culture and context?\n" +
                    "\n" +
                    "There are three major branches of ethics:\n" +
                    "\n" +
                    "Meta-ethics: Explores what morality means. Is morality based on emotions, reason, or divine commands?\n" +
                    "Normative ethics: Attempts to define principles of right and wrong, such as duty-based (deontological) ethics or consequence-based (utilitarian) ethics.\n" +
                    "Applied ethics: Deals with real-world issues like medical ethics, business ethics, and environmental ethics.\n" +
                    "Moral dilemmas arise when different ethical principles lead to conflicting conclusions. For example, lying is usually wrong, but what if lying saves someone’s life?",
            "Moral relativism argues that morality is subjective and depends on cultural or personal perspectives. For example, arranged marriages may be acceptable in one society but seen as unethical in another.\n" +
                    "Moral absolutism claims that some moral principles are universal and apply in all situations. For example, murder is always wrong, regardless of culture or circumstances.\n" +
                    "The debate between relativism and absolutism is important in discussions about human rights, cultural practices, and international law.",
            "The Trolley Problem is a classic ethical thought experiment:\n" +
                    "\n" +
                    "A runaway trolley is heading toward five people tied to the tracks.\n" +
                    "You can pull a lever to divert the trolley to another track, but it will hit one person instead.\n" +
                    "Do you pull the lever?\n" +
                    "\n" +
                    "Utilitarians (who believe in maximizing happiness) argue that sacrificing one to save five is the right choice.\n" +
                    "Deontologists (who believe in duty-based ethics) argue that actively causing harm (pulling the lever) is morally wrong, even if it leads to fewer deaths.",
            "Technology raises new ethical challenges:\n" +
                    "\n" +
                    "Privacy and Surveillance: Governments and companies collect vast amounts of personal data. Is it ethical to sacrifice privacy for security?\n" +
                    "Artificial Intelligence: AI can make decisions, but who is responsible if it makes a mistake? Should AI have rights?\n" +
                    "Automation and Job Loss: Should companies be responsible for helping workers displaced by automation?",
            "Medical ethics deals with the moral implications of medical decisions.\n" +
                    "\n" +
                    "Euthanasia (assisted suicide): Should terminally ill patients have the right to end their own lives? Some argue this is a compassionate choice, while others believe it devalues human life.\n" +
                    "Organ Donation: Should organs be automatically donated unless a person opts out? This could save lives but raises concerns about personal choice and religious beliefs.\n" +
                    "These dilemmas force societies to balance individual rights with the greater good.",
            "Ethics extends to how we treat the planet and other living beings.\n" +
                    "\n" +
                    "Animal Rights: Should animals have legal protections similar to humans? Some philosophers argue that animals feel pain and deserve rights, while others say humans have priority.\n" +
                    "Climate Change Responsibility: Should wealthy nations, which have contributed more to global warming, bear more responsibility in solving it?\n" +
                    "Governments and businesses must make ethical choices about sustainability, pollution, and conservation.",
            "Companies have moral responsibilities beyond making money. Ethical issues in business include:\n" +
                    "\n" +
                    "Fair Wages: Should companies be allowed to pay workers very low wages in developing countries?\n" +
                    "Consumer Safety: Should businesses be required to recall unsafe products, even if it leads to financial losses?\n" +
                    "Corporate Influence in Politics: Should businesses have the right to fund political campaigns?\n" +
                    "Poor ethical choices in business can lead to scandals, such as companies hiding harmful product effects (e.g., cigarette companies denying smoking risks).\n" +
                    "\n",
            "Just War Theory: Can war ever be ethical? The theory suggests war is justifiable only if it meets criteria like self-defense, last resort, and proportionality.\n" +
                    "Terrorism and Torture: Is it ever acceptable to use torture to extract information from terrorists? Some argue that it saves lives, while others say it violates human rights.\n" +
                    "These dilemmas are critical in international relations and defense policies."
        )



        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}