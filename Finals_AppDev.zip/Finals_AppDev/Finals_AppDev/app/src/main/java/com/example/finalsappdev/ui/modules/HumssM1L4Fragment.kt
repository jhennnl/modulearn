package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM1L4Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 1: Arts and Culture"
        binding.lessontextView.text = "Lesson 4: Creative Writing & Analysis"
        binding.readingContent.text = "Creative writing is a form of artistic expression that allows individuals to communicate thoughts, emotions, and ideas in imaginative ways."

        val heading = listOf(
            "Storytelling",
            "Imagery and Symbolism",
            "Theme and Interpretation",
            "Self-Expression",
            "Exploration of Ideas",
            "Cultural Reflection",
            "Emotional Connection",
            "Types of Creative Writing",
            "Elements of Effective Creative Writing",
            "Literary Analysis: Understanding Creative Works"
        )
        val lessons = listOf(
            "Creative writing revolves around developing compelling narratives with well-structured plots, engaging characters, and vivid settings.",
            "Writers use literary devices such as metaphor, simile, and symbolism to enhance meaning and evoke emotions.",
            "A strong theme gives depth to a story, allowing readers to connect with underlying messages about society, human nature, or morality.",
            "Writers can explore personal thoughts, emotions, and experiences.",
            "Writers can challenge existing norms, explore different viewpoints, and reflect on societal issues.",
            "Literature captures cultural traditions, historical moments, and collective experiences.",
            "Readers and writers develop empathy by experiencing different perspectives and emotions through characters and stories.",
            "There are several forms of creative writing, each with unique characteristics:\n" +
                    "\n" +
                    "a. Poetry\n" +
                    "Poetry is a highly expressive form that uses rhythm, rhyme, and figurative language to convey emotions and themes. It often focuses on imagery and condensed language to create impact.\n" +
                    "Examples:\n" +
                    "\n" +
                    "Lyrical Poetry: Expresses personal emotions (e.g., sonnets, odes).\n" +
                    "Narrative Poetry: Tells a story (e.g., epics, ballads).\n" +
                    "Free Verse: Lacks a fixed structure but maintains artistic expression.\n" +
                    "b. Fiction (Short Stories & Novels)\n" +
                    "Fictional writing involves creating imaginary characters, settings, and plots.\n" +
                    "Elements of Fiction:\n" +
                    "\n" +
                    "Plot: The sequence of events in a story (exposition, rising action, climax, falling action, resolution).\n" +
                    "Characterization: Development of characters with personalities, motivations, and growth.\n" +
                    "Setting: The time and place where the story occurs.\n" +
                    "Conflict: The struggle between opposing forces (internal or external).\n" +
                    "Theme: The underlying message or central idea.\n" +
                    "c. Drama & Playwriting\n" +
                    "Drama is written for performance on stage, screen, or radio. It relies on dialogue and action rather than narration.\n" +
                    "Types:\n" +
                    "\n" +
                    "Tragedy: Serious themes, often ending in catastrophe.\n" +
                    "Comedy: Light-hearted and humorous.\n" +
                    "Historical Drama: Based on real events.\n" +
                    "d. Creative Nonfiction\n" +
                    "This genre blends factual storytelling with literary techniques.\n" +
                    "Examples:\n" +
                    "\n" +
                    "Memoirs: Personal life stories focusing on significant events.\n" +
                    "Essays: Reflective pieces on specific themes or experiences.\n" +
                    "Travel Writing: Descriptive accounts of places and cultures.",
            "To create compelling works, writers use various literary techniques:\n" +
                    "\n" +
                    "a. Imagery & Description\n" +
                    "Using vivid details that appeal to the senses helps bring scenes to life.\n" +
                    "\n" +
                    "Example: \"The crisp autumn air carried the scent of damp earth and burning wood.\"\n" +
                    "b. Symbolism & Metaphor\n" +
                    "Writers use symbols to represent ideas or emotions beyond their literal meaning.\n" +
                    "\n" +
                    "Example: A storm representing chaos or uncertainty in a character’s life.\n" +
                    "c. Dialogue\n" +
                    "Dialogue adds realism to writing by revealing character personalities and relationships.\n" +
                    "\n" +
                    "Example:\n" +
                    "\"I can’t believe you did that!\" she exclaimed.\n" +
                    "\"I had no choice,\" he murmured, looking away.\n" +
                    "d. Perspective & Narrative Voice\n" +
                    "Stories can be told from different perspectives:\n" +
                    "\n" +
                    "First-Person: \"I walked through the silent streets.\"\n" +
                    "Third-Person Limited: \"She hesitated before entering the room.\"\n" +
                    "Third-Person Omniscient: \"He didn’t know it yet, but his life was about to change forever.\"",
            "Literary analysis involves critically examining elements of a text to interpret its meaning and significance.\n" +
                    "\n" +
                    "a. Identifying Themes\n" +
                    "What is the deeper message behind the story?\n" +
                    "Does the story address universal human experiences?\n" +
                    "b. Character Analysis\n" +
                    "How do characters change throughout the story?\n" +
                    "What motivates their actions?\n" +
                    "c. Narrative Structure\n" +
                    "Does the story follow a traditional arc, or does it experiment with time and perspective?\n" +
                    "How does the structure enhance the reader’s experience?\n" +
                    "d. Writing Style & Literary Devices\n" +
                    "How does the author use imagery, symbolism, or irony to create depth?"
        )


        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
