package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentScoreReviewBinding

class HumssScoreFragment : Fragment() {

    private lateinit var scoreTextView: TextView
    private lateinit var questionContainer: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentScoreReviewBinding.inflate(inflater, container, false)
        binding.titletextView.text = "HUMSS Quiz Score"

        scoreTextView = binding.scoreText
        questionContainer = binding.questionContainer

        val score = arguments?.getInt("score", 0) ?: 0
        val questions = arguments?.getStringArrayList("questions")
        val correctAnswers = arguments?.getIntegerArrayList("correctAnswers")
        val userAnswers = arguments?.getIntegerArrayList("userAnswers")
        val answerChoices = arguments?.getSerializable("answerChoices") as? ArrayList<List<String>>

        scoreTextView.text = "Your Score: $score"

        questions?.forEachIndexed { index, question ->
            val correctAnswer = correctAnswers?.get(index) ?: -1
            val userAnswer = userAnswers?.get(index) ?: -1
            val choices = answerChoices?.get(index) ?: listOf("A", "B", "C", "D")

            val questionView = layoutInflater.inflate(R.layout.item_question, questionContainer, false)

            val heading = questionView.findViewById<TextView>(R.id.heading)
            val context = questionView.findViewById<TextView>(R.id.context)
            val correctAnswerTextView = questionView.findViewById<TextView>(R.id.correctanswertextView)
            val userAnswerTextView = questionView.findViewById<TextView>(R.id.useranswertextView)

            heading.text = "Question ${index + 1}:"
            context.text = question
            correctAnswerTextView.text = "Correct Answer: ${getAnswerText(correctAnswer, choices)}"
            userAnswerTextView.text = "Your Answer: ${getAnswerText(userAnswer, choices)}"

            questionContainer.addView(questionView)
        }

        binding.returntomoduleBtn.setOnClickListener {
            findNavController().navigate(R.id.Score_to_humss)
        }


        return binding.root
    }

    private fun getAnswerText(answerIndex: Int, choices: List<String>): String {
        return when (answerIndex) {
            0 -> "A. ${choices[0]}"
            1 -> "B. ${choices[1]}"
            2 -> "C. ${choices[2]}"
            3 -> "D. ${choices[3]}"
            else -> "Not Answered"
        }
    }
}
