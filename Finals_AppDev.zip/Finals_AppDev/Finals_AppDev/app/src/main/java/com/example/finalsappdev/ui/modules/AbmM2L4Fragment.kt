package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM2L4Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Business and Marketing"
        binding.lessontextView.text = "Lesson 4: Business Ethics"
        binding.readingContent.text = "Business ethics refers to the moral principles that guide the way a business behaves."

        val lessons = listOf(
            "Integrity in business means being honest and transparent.",
            "Corporate social responsibility involves businesses giving back to the community.",
            "Fair treatment of employees ensures a positive work environment.",
            "Customer trust is built through ethical business practices.",
            "Avoiding corruption and fraud maintains a company’s reputation."
        )

        val heading = listOf(
            "Integrity: Honesty in Business",
            "Corporate Social Responsibility: Giving Back",
            "Fair Treatment: Employee Rights",
            "Customer Trust: Ethical Business Practices",
            "Avoiding Corruption: Protecting Reputation"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
