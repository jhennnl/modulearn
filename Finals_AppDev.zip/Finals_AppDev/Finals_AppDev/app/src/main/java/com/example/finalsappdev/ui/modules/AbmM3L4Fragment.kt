package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM3L4Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Financial Management"
        binding.lessontextView.text = "Lesson 4: Understanding Taxes"
        binding.readingContent.text = "Effective cost management is essential for maintaining profitability and ensuring long-term business success."

        val lessons = listOf(
            "Fixed costs are business expenses that remain constant regardless of production or sales levels. Examples include rent, salaries, and insurance. Managing fixed costs ensures financial stability, as these expenses must be paid regardless of revenue.",
            "Variable costs fluctuate based on production levels. These include raw materials, utilities, and sales commissions. Businesses must track variable costs carefully to maintain profitability and adjust production as needed.",
            "Cost-cutting strategies help businesses reduce expenses without compromising quality. Techniques include negotiating better supplier deals, reducing waste, automating processes, and outsourcing certain tasks to save money.",
            "Break-even analysis helps businesses determine how much they need to sell to cover costs. By understanding the break-even point, companies can set realistic pricing strategies and sales targets to ensure profitability.",
            "Operational efficiency refers to maximizing output while minimizing costs. This involves improving workflows, investing in technology, and optimizing resource allocation to ensure business sustainability."
        )

        val heading = listOf(
            "Fixed Costs: Understanding Constant Expenses",
            "Variable Costs: Managing Fluctuating Expenses",
            "Cost-Cutting Strategies: Reducing Business Expenses",
            "Break-even Analysis: Ensuring Profitability",
            "Operational Efficiency: Optimizing Business Performance"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
