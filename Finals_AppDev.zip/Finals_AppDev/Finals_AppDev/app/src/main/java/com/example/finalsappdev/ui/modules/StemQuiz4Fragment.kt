package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentQuizBinding

class StemQuiz4Fragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!

    private val questions = listOf(
        "What is the value of π (pi) approximately?" to listOf("2.14", "3.14", "4.14", "5.14"),
        "What is the square root of 144?" to listOf("10", "11", "12", "13"),
        "What is the result of 8 × 7?" to listOf("54", "56", "58", "60"),
        "What is the term for a number that is only divisible by 1 and itself?" to listOf("Prime Number", "Composite Number", "Even Number", "Odd Number"),
        "What is the perimeter of a square with side length 5?" to listOf("10", "15", "20", "25"),
        "What is the sum of the angles in a triangle?" to listOf("90°", "180°", "270°", "360°"),
        "What is the value of 2³?" to listOf("4", "6", "8", "10"),
        "What is the formula for the area of a circle?" to listOf("πr²", "2πr", "πd", "r²"),
        "If a = 5 and b = 3, what is the value of a² + b²?" to listOf("25", "34", "35", "40"),
        "What is the term for the longest side of a right triangle?" to listOf("Base", "Height", "Hypotenuse", "Diagonal")
    )

    private val correctAnswers = listOf(1, 2, 1, 0, 2, 1, 2, 0, 1, 2)
    private var currentQuestionIndex = 0

    private val userAnswers = mutableListOf<Int>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        binding.titleQuiz.text = "STEM Quiz 4"
        binding.backStrand.text = "Module 4: Mathematics"

        savedInstanceState?.let {
            currentQuestionIndex = it.getInt("currentQuestionIndex", 0)
        }

        updateQuestion()

        binding.backarrowBtn.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.btnNext.setOnClickListener {
            if (currentQuestionIndex < questions.size - 1) {
                saveUserAnswer()
                currentQuestionIndex++
                updateQuestion()
            }
        }

        binding.btnBack.setOnClickListener {
            if (currentQuestionIndex > 0) {
                saveUserAnswer()
                currentQuestionIndex--
                updateQuestion()
            }
        }

        binding.btnFinish.setOnClickListener {
            saveUserAnswer()
            navigateToScoreFragment()
        }

        return binding.root
    }

    private fun updateQuestion() {
        val (question, answers) = questions[currentQuestionIndex]

        binding.heading1.text = "Question ${currentQuestionIndex + 1}:"
        binding.context1.text = question
        binding.answer1.text = "A. ${answers[0]}"
        binding.answer2.text = "B. ${answers[1]}"
        binding.answer3.text = "C. ${answers[2]}"
        binding.answer4.text = "D. ${answers[3]}"

        binding.radioGroup.clearCheck()

        binding.btnBack.visibility = if (currentQuestionIndex == 0) View.GONE else View.VISIBLE
        binding.btnNext.visibility = if (currentQuestionIndex == questions.size - 1) View.GONE else View.VISIBLE
        binding.btnFinish.visibility = if (currentQuestionIndex == questions.size - 1) View.VISIBLE else View.GONE
    }

    private fun saveUserAnswer() {
        val selectedRadioButtonId = binding.radioGroup.checkedRadioButtonId
        val selectedAnswerIndex = when (selectedRadioButtonId) {
            binding.answer1.id -> 0
            binding.answer2.id -> 1
            binding.answer3.id -> 2
            binding.answer4.id -> 3
            else -> -1
        }

        if (userAnswers.size > currentQuestionIndex) {
            userAnswers[currentQuestionIndex] = selectedAnswerIndex
        } else {
            userAnswers.add(selectedAnswerIndex)
        }
    }


    private fun navigateToScoreFragment() {
        val score = calculateScore()
        val bundle = Bundle().apply {
            putInt("score", score)
            putStringArrayList("questions", ArrayList(questions.map { it.first }))
            putIntegerArrayList("correctAnswers", ArrayList(correctAnswers))
            putIntegerArrayList("userAnswers", ArrayList(userAnswers))
            putSerializable("answerChoices", ArrayList(questions.map { it.second }))
        }

        findNavController().navigate(R.id.STEMQ4_to_Score, bundle)
    }


    private fun calculateScore(): Int {
        var score = 0

        for (i in userAnswers.indices) {
            if (userAnswers[i] != -1) {
                if (userAnswers[i] == correctAnswers[i]) {
                    score++
                }
            }
        }

        return score
    }



    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("currentQuestionIndex", currentQuestionIndex)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
