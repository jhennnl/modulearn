package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM4L2Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Mathematics"
        binding.lessontextView.text = "Lesson 2: Trigonometry"
        binding.readingContent.text = "Trigonometry is a branch of mathematics that studies the relationships between the angles and sides of triangles. "

        val heading = listOf(
            "Trigonometric Ratios",
            "Common Trigonometric Values",
            "Pythagorean Theorem",
            "Trigonometric Identities",
            "Inverse Trigonometric Functions",
            "Radians and Degrees",
            "Applications of Trigonometry"
        )

        val lessons = listOf(
            "The three primary trigonometric functions are sine (sin), cosine (cos), and tangent (tan). These functions relate the angles of a right triangle to the lengths of its sides. For example, sin θ = opposite/hypotenuse, cos θ = adjacent/hypotenuse, and tan θ = opposite/adjacent.",
            "Certain angles have well-known trigonometric values. For instance, sin 45° = √2/2, cos 60° = 1/2, and tan 30° = 1/√3. These values are useful for solving trigonometric equations and simplifying expressions.",
            "The Pythagorean Theorem states that in a right triangle, the square of the hypotenuse is equal to the sum of the squares of the other two sides: a² + b² = c². This theorem is useful in determining unknown side lengths when two sides are known.",
            "One fundamental identity in trigonometry is sin² θ + cos² θ = 1. This identity is frequently used to simplify trigonometric expressions and solve equations.",
            "Inverse trigonometric functions help determine angles when given trigonometric ratios. For example, if sin θ = 1/2, then θ = sin⁻¹(1/2) = 30°. These functions are essential in solving problems where angles need to be found.",
            "Angles can be measured in degrees or radians. The conversion between them follows the formula π radians = 180°. For example, π/4 radians = 45°, and π/3 radians = 60°.",
            "Trigonometry is applied in various fields such as astronomy, engineering, and navigation. It helps in determining distances, angles of elevation and depression, and wave functions in physics. Mastering these concepts provides a strong foundation for advanced mathematical studies."
        )


        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }


        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M4L1_to_M4)
        }

        return binding.root
    }
}