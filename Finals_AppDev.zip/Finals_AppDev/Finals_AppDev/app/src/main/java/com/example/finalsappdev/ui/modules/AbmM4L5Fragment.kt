package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class AbmM4L5Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 4: Marketing Management"
        binding.lessontextView.text = "Lesson 5: Digital Marketing and Social Media Strategies"
        binding.readingContent.text = """
            Digital marketing is the use of online platforms, social media, search engines, and 
            email campaigns to promote products and services. Businesses must develop effective 
            digital strategies to engage with customers and increase brand awareness.
        """.trimIndent()

        val lessons = listOf(
            "Social media marketing involves using platforms like Facebook, Instagram, Twitter, and LinkedIn to reach target audiences. Businesses create engaging content, run ads, and interact with customers in real-time.",
            "Search engine optimization (SEO) helps businesses rank higher on search engines like Google by optimizing website content, keywords, and backlinks. Higher rankings increase visibility and drive more traffic to websites.",
            "Email marketing allows businesses to send personalized messages, promotions, and newsletters directly to customers. It is a cost-effective way to build relationships and encourage repeat purchases.",
            "Content marketing involves creating valuable blog posts, videos, infographics, and other content to educate and attract customers. High-quality content builds trust and positions businesses as industry leaders.",
            "Influencer marketing leverages social media personalities with large followings to promote products. Influencers help businesses reach new audiences and enhance credibility through authentic recommendations."
        )

        val heading = listOf(
            "Social Media Marketing: Engaging with Audiences",
            "SEO: Optimizing Online Visibility",
            "Email Marketing: Personalized Customer Engagement",
            "Content Marketing: Building Brand Authority",
            "Influencer Marketing: Partnering with Online Influencers"
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}
