package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentModulesBinding

class HumssModule3Fragment : Fragment() {

    private var _binding: FragmentModulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataList: ArrayList<dataClass>
    private lateinit var imageList: Array<Int>
    private lateinit var titleList: Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentModulesBinding.inflate(inflater, container, false)
        binding.backStrand.text = "Humss Module"
        binding.title.text = "Module 3: Psychology and Media"

        imageList = arrayOf(
            R.drawable.human,
            R.drawable.publicmedia,
            R.drawable.persuasion
        )

        titleList = arrayOf(
            "Lesson 1: Human Development",
            "Lesson 2: Media & Public Influence",
            "Lesson 3: The Power of Persuasion"
        )


        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            adapter = adapterClass(getData()) { selectedItem ->
                if (selectedItem.dataTitle == "Lesson 1: Human Development") {
                    findNavController().navigate(R.id.HUMSS_M3_to_L1)
                }
                if (selectedItem.dataTitle == "Lesson 2: Media & Public Influence") {
                    findNavController().navigate(R.id.HUMSS_M3_to_L2)
                }
                if (selectedItem.dataTitle == "Lesson 3: The Power of Persuasion") {
                    findNavController().navigate(R.id.HUMSS_M3_to_L3)
                }
            }
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData(): ArrayList<dataClass> {
        return ArrayList<dataClass>().apply {
            for (i in imageList.indices) {
                add(dataClass(imageList[i], titleList[i]))
            }
        }
    }

}