package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class StemM3L1Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 3: Engineering"
        binding.lessontextView.text = "Lesson 1: Introduction to Engineering"
        binding.readingContent.text = "Engineering is a field that applies scientific and practical knowledge to solve real-world problems. It plays a crucial role in designing and building structures, machines, and systems that improve daily life."

        val heading = listOf(
            "What is Engineering?",
            "Branches of Engineering",
            "The Father of Engineering",
            "The Goal of Engineering",
            "Engineering in Everyday Life",
            "Difference Between Science and Engineering",
            "Importance of Teamwork in Engineering",
            "The Role of Prototyping",
            "Famous Engineers and Their Contributions"
        )

        val lessons = listOf(
            "Engineering is the application of scientific principles to design, create, and improve structures, machines, systems, and processes. It involves problem-solving, innovation, and efficiency.",
            "Engineering is a vast field with many specialized branches. Some of the main branches include:\n" +
                    "\n" +
                    "Mechanical Engineering: Focuses on designing and manufacturing mechanical systems such as engines, tools, and machinery.\n" +
                    "\n" +
                    "Electrical Engineering: Deals with the study and application of electricity, electronics, and electromagnetism.\n" +
                    "\n" +
                    "Chemical Engineering: Involves the production and transformation of chemicals for various applications, including pharmaceuticals and materials.\n" +
                    "\n" +
                    "Civil Engineering: Concerned with designing and constructing infrastructure like roads, bridges, and buildings.\n" +
                    "\n" +
                    "Software Engineering: Involves designing, developing, and maintaining software applications.\n" +
                    "\n" +
                    "Aerospace Engineering: Focuses on designing and manufacturing aircraft, spacecraft, and related systems.",
            "There is no single \"Father of Engineering\" because engineering has evolved over centuries with contributions from many great minds. However, notable historical figures include:\n" +
                    "\n" +
                    "Archimedes: Known for his work in mechanics and fluid dynamics.\n" +
                    "\n" +
                    "Leonardo da Vinci: A Renaissance engineer and inventor who designed machines and engineering concepts ahead of his time.\n" +
                    "\n" +
                    "Imhotep: An ancient Egyptian architect and engineer credited with designing the step pyramid.",
            "The primary goal of engineering is to solve real-world problems through practical solutions. Engineers develop technology and infrastructure to improve human life, enhance efficiency, and drive innovation in various industries such as healthcare, transportation, and energy.",
            "Engineering plays a crucial role in numerous fields, including:\n" +
                    "\n" +
                    "Medicine: Developing medical devices, imaging systems, and prosthetics.\n" +
                    "\n" +
                    "Technology: Creating software, electronics, and communication networks.\n" +
                    "\n" +
                    "Infrastructure: Building roads, bridges, and transportation systems.\n" +
                    "\n" +
                    "Energy: Designing renewable energy solutions and power grids.",
            "Science focuses on discovering and understanding natural laws.\n" +
                    "\n" +
                    "Engineering applies scientific principles to create functional solutions.\n" +
                    "\n" +
                    "Science explains \"why\" things happen, while engineering explains \"how\" to use this knowledge to build practical applications.",
            "Engineering projects are often complex and require collaboration among professionals with different skills. Teamwork is essential because:\n" +
                    "\n" +
                    "It combines diverse expertise to solve intricate problems.\n" +
                    "\n" +
                    "It enhances creativity and innovation.\n" +
                    "\n" +
                    "It ensures efficient project execution and management.",
            "A prototype is an early version of a product or system used to test and refine designs before mass production. Prototyping helps engineers:\n" +
                    "\n" +
                    "Identify design flaws.\n" +
                    "\n" +
                    "Improve functionality and efficiency.\n" +
                    "\n" +
                    "Reduce production costs by minimizing errors.",
            "Engineering has a rich history of pioneers who have transformed the world. Some notable engineers include:\n" +
                    "\n" +
                    "Nikola Tesla: Developed the alternating current (AC) electrical system.\n" +
                    "\n" +
                    "Marie Curie: Made groundbreaking discoveries in radioactivity.\n" +
                    "\n" +
                    "Albert Einstein: Contributed to physics with the Theory of Relativity, though he was more of a physicist than an engineer.\n" +
                    "\n" +
                    "Isaac Newton: Formulated the Laws of Motion, which are fundamental to engineering mechanics."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.STEM_M3L1_to_M3)
        }

        return binding.root
    }
}