package com.example.finalsappdev.ui.modules

data class dataClass(var dataImage: Int, var dataTitle: String)