package com.example.finalsappdev.ui.modules

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.finalsappdev.R
import com.example.finalsappdev.databinding.FragmentLessonMatsBinding
import com.example.finalsappdev.databinding.ItemLessonBinding

class HumssM2L3Fragment : Fragment() {
    private lateinit var binding: FragmentLessonMatsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLessonMatsBinding.inflate(inflater, container, false)

        binding.backStrand.text = "Module 2: Philosophy and Society"
        binding.lessontextView.text = "Lesson 3: Political System & Power"
        binding.readingContent.text = "Political philosophy examines how societies should be organized and how power should be distributed."

        val heading = listOf(
            "Democracy vs. Authoritarianism",
            "The Role of the State",
            "Socialism vs. Capitalism",
            "Human Rights and the Law",
            "Revolution and Civil Disobedience",
            "Globalization and International Politics",
            "Propaganda and Political Manipulation"
        )

        val lessons = listOf(
            "Democracy values citizen participation, free elections, and human rights. Examples: the U.S., Canada, and most European countries.\n" +
                    "Authoritarianism centralizes power in a ruler or small elite, often restricting freedoms. Examples: North Korea, China (in some aspects).\n" +
                    "Each system has strengths and weaknesses. Democracy can be slow and inefficient, while authoritarianism can be effective but oppressive.",
            "Should governments have a minimal role (libertarianism) or a strong role (social democracy)?\n" +
                    "\n" +
                    "Libertarians argue that too much government control limits freedom.\n" +
                    "Social democrats believe the state should provide social services like healthcare and education.\n" +
                    "This debate affects policies on taxation, public services, and economic regulations.",
            "Capitalism emphasizes free markets and private ownership. It promotes innovation but can lead to inequality.\n" +
                    "Socialism advocates for collective ownership of resources to reduce inequality. Critics argue it reduces motivation and efficiency.\n" +
                    "Most modern economies are mixed, combining capitalist and socialist elements.",
            "Universal Declaration of Human Rights: Defines basic human rights like freedom of speech and protection from torture.\n" +
                    "Some governments ignore these rights for political or economic gain, leading to international conflicts.",
            "When is it justified to break laws or overthrow a government?\n" +
                    "\n" +
                    "Peaceful protests (e.g., Gandhi, Martin Luther King Jr.) challenge unjust laws nonviolently.\n" +
                    "Violent revolutions (e.g., French Revolution) can bring change but often lead to instability.\n" +
                    "This debate is key in movements for social justice, democracy, and freedom.\n" +
                    "\n",
            "Globalization connects economies and cultures but can exploit weaker nations.\n" +
                    "International Organizations like the UN and NATO help maintain peace but often face criticism for bias or ineffectiveness.\n" +
                    "How should nations cooperate to address global challenges like pandemics, poverty, and climate change?",
            "Governments and media influence public opinion through propaganda.\n" +
                    "\n" +
                    "Fake news and misinformation shape elections and policies.\n" +
                    "Authoritarian regimes use censorship to control narratives.\n" +
                    "With social media, propaganda spreads faster than ever, raising concerns about truth and democracy."
        )

        lessons.forEachIndexed { index, lesson ->
            val lessonBinding = ItemLessonBinding.inflate(inflater, binding.lessonContainer, false)
            lessonBinding.heading1.text = heading[index]
            lessonBinding.context1.text = lesson
            binding.lessonContainer.addView(lessonBinding.root)
        }

        binding.backarrowBtn.setOnClickListener {
            findNavController().navigate(R.id.backBtn)
        }

        return binding.root
    }
}